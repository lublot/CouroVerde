-- pjl SQL Dump
-- Server version:5.7.14
-- Generated: 2017-07-21 10:14:24
-- Current PHP version: 7.0.10
-- localhost: localhost
-- Database:webMuseu
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema webMuseu
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `webMuseu` DEFAULT CHARACTER SET utf8 ;
USE `webMuseu` ;

-- -----------------------------------------------------
-- Table `webMuseu`.`arquivo`
-- -----------------------------------------------------

DROP TABLE IF EXISTS arquivo;
CREATE TABLE `arquivo` (
  `idArquivo` int(11) NOT NULL AUTO_INCREMENT,
  `caminho` varchar(200) NOT NULL,
  `tipo` enum('IMAGEM','MODELO3D','TEXTURA') NOT NULL,
  PRIMARY KEY (`idArquivo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `arquivo`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`arquivoobra`
-- -----------------------------------------------------

DROP TABLE IF EXISTS arquivoobra;
CREATE TABLE `arquivoobra` (
  `idObra` int(11) NOT NULL,
  `idArquivo` int(11) NOT NULL,
  PRIMARY KEY (`idObra`,`idArquivo`),
  KEY `fk_idArquivo_idx` (`idArquivo`),
  CONSTRAINT `fk_ArquivoObra_Arquivo` FOREIGN KEY (`idArquivo`) REFERENCES `arquivo` (`idArquivo`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ArquivoObra_Obra` FOREIGN KEY (`idObra`) REFERENCES `obra` (`numeroInventario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `arquivoobra`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`backup`
-- -----------------------------------------------------

DROP TABLE IF EXISTS backup;
CREATE TABLE `backup` (
  `idBackup` int(11) NOT NULL AUTO_INCREMENT,
  `caminho` varchar(200) NOT NULL,
  `dataHora` datetime NOT NULL,
  PRIMARY KEY (`idBackup`)
) ENGINE=InnoDB AUTO_INCREMENT=446 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `backup`
--

INSERT INTO backup (`idBackup`,`caminho`,`dataHora`) VALUES ("436","backups/backup_2017-07-2122-07-49.zip","2017-07-21 22:07:49");
INSERT INTO backup (`idBackup`,`caminho`,`dataHora`) VALUES ("437","backups/backup_2017-07-2122-07-49.zip","2017-07-21 22:07:49");
INSERT INTO backup (`idBackup`,`caminho`,`dataHora`) VALUES ("438","backups/backup_2017-07-2122-07-49.zip","2017-07-21 22:07:49");
INSERT INTO backup (`idBackup`,`caminho`,`dataHora`) VALUES ("439","backups/backup_2017-07-2122-11-02.zip","2017-07-21 22:11:02");
INSERT INTO backup (`idBackup`,`caminho`,`dataHora`) VALUES ("440","backups/backup_2017-07-2122-11-02.zip","2017-07-21 22:11:02");
INSERT INTO backup (`idBackup`,`caminho`,`dataHora`) VALUES ("441","backups/backup_2017-07-2122-11-03.zip","2017-07-21 22:11:03");
INSERT INTO backup (`idBackup`,`caminho`,`dataHora`) VALUES ("442","backups/backup_2017-07-2122-11-28.zip","2017-07-21 22:11:28");
INSERT INTO backup (`idBackup`,`caminho`,`dataHora`) VALUES ("443","backups/backup_2017-07-2122-11-28.zip","2017-07-21 22:11:28");
INSERT INTO backup (`idBackup`,`caminho`,`dataHora`) VALUES ("444","backups/backup_2017-07-2122-11-28.zip","2017-07-21 22:11:28");
INSERT INTO backup (`idBackup`,`caminho`,`dataHora`) VALUES ("445","backups/backup_2017-07-2122-14-24.zip","2017-07-21 22:14:24");



-- -----------------------------------------------------
-- Table `webMuseu`.`classificacao`
-- -----------------------------------------------------

DROP TABLE IF EXISTS classificacao;
CREATE TABLE `classificacao` (
  `idClassificacao` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  PRIMARY KEY (`idClassificacao`),
  UNIQUE KEY `nome_UNIQUE` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `classificacao`
--

INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("1","Classificao");



-- -----------------------------------------------------
-- Table `webMuseu`.`colecao`
-- -----------------------------------------------------

DROP TABLE IF EXISTS colecao;
CREATE TABLE `colecao` (
  `idColecao` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  PRIMARY KEY (`idColecao`),
  UNIQUE KEY `nome_UNIQUE` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `colecao`
--

INSERT INTO colecao (`idColecao`,`nome`) VALUES ("1","Colecao");



-- -----------------------------------------------------
-- Table `webMuseu`.`fotografia`
-- -----------------------------------------------------

DROP TABLE IF EXISTS fotografia;
CREATE TABLE `fotografia` (
  `idFotografia` int(11) NOT NULL,
  `Fotografo` varchar(50) DEFAULT NULL,
  `data` date DEFAULT NULL,
  `autorFotografia` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`idFotografia`),
  CONSTRAINT `fk_Fotografia_Obra` FOREIGN KEY (`idFotografia`) REFERENCES `obra` (`numeroInventario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `fotografia`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`funcionario`
-- -----------------------------------------------------

DROP TABLE IF EXISTS funcionario;
CREATE TABLE `funcionario` (
  `matricula` int(11) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  `funcao` varchar(45) NOT NULL,
  `cadastroObra` tinyint(1) NOT NULL,
  `gerenciaObra` tinyint(1) NOT NULL,
  `remocaoObra` tinyint(1) NOT NULL,
  `cadastroNoticia` tinyint(1) NOT NULL,
  `gerenciaNoticia` tinyint(1) NOT NULL,
  `remocaoNoticia` tinyint(1) NOT NULL,
  `backup` tinyint(1) NOT NULL,
  PRIMARY KEY (`matricula`),
  UNIQUE KEY `idUsuario_UNIQUE` (`idUsuario`),
  KEY `fk_Funcionario_Usuario_idx` (`idUsuario`),
  CONSTRAINT `fk_Funcionario_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `funcionario`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`logalteracoes`
-- -----------------------------------------------------

DROP TABLE IF EXISTS logalteracoes;
CREATE TABLE `logalteracoes` (
  `idLogAlteracoes` int(11) NOT NULL AUTO_INCREMENT,
  `matriculaFuncionario` int(11) NOT NULL,
  `idItemAlterado` int(11) NOT NULL,
  `tipoItemAlterado` enum('NOTICIA','OBRA','BACKUP','FUNCIONARIO') NOT NULL,
  `descricao` varchar(1000) NOT NULL,
  `dataHora` datetime NOT NULL,
  PRIMARY KEY (`idLogAlteracoes`),
  KEY `fk_LogAlteracoes_Funcionario_idx` (`matriculaFuncionario`),
  CONSTRAINT `fk_LogAlteracoes_Funcionario` FOREIGN KEY (`matriculaFuncionario`) REFERENCES `funcionario` (`matricula`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `logalteracoes`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`noticia`
-- -----------------------------------------------------

DROP TABLE IF EXISTS noticia;
CREATE TABLE `noticia` (
  `idNoticia` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(50) NOT NULL,
  `subtitulo` varchar(100) DEFAULT NULL,
  `descricao` varchar(500) DEFAULT NULL,
  `caminhoImagem` varchar(200) DEFAULT NULL,
  `data` date NOT NULL,
  PRIMARY KEY (`idNoticia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `noticia`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`obra`
-- -----------------------------------------------------

DROP TABLE IF EXISTS obra;
CREATE TABLE `obra` (
  `numeroInventario` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `funcao` varchar(45) DEFAULT NULL,
  `origem` varchar(45) DEFAULT NULL,
  `procedencia` varchar(45) DEFAULT NULL,
  `descricao` varchar(3000) DEFAULT NULL,
  `idColecao` int(11) NOT NULL,
  `idClassificacao` int(11) NOT NULL,
  `altura` float DEFAULT NULL,
  `largura` float DEFAULT NULL,
  `diametro` float DEFAULT NULL,
  `peso` float DEFAULT NULL,
  `comprimento` float DEFAULT NULL,
  `materiaisContruidos` varchar(200) DEFAULT NULL,
  `tecnicasFabricacao` varchar(100) DEFAULT NULL,
  `autoria` varchar(45) DEFAULT NULL,
  `marcasInscricoes` varchar(200) DEFAULT NULL,
  `historicoObjeto` varchar(200) DEFAULT NULL,
  `modoAquisicao` varchar(45) DEFAULT NULL,
  `dataAquisicao` date DEFAULT NULL,
  `autor` varchar(45) DEFAULT NULL,
  `observacoes` varchar(100) DEFAULT NULL,
  `estadoConservacao` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`numeroInventario`),
  KEY `idCategoria_idx` (`idClassificacao`),
  KEY `fk_idColecao_obra_idx` (`idColecao`),
  CONSTRAINT `fk_Obra_Classificacao` FOREIGN KEY (`idClassificacao`) REFERENCES `classificacao` (`idClassificacao`) ON UPDATE CASCADE,
  CONSTRAINT `fk_Obra_Colecao` FOREIGN KEY (`idColecao`) REFERENCES `colecao` (`idColecao`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `obra`
--

INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`) VALUES ("1",""1"",""1"",""1"",""1"",""1"",""1"","1","1","1","1","1","1","1",""1"",""1"",""1"",""1"",""1"",""1"","2017-07-04",""1"",""1"",""1"");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`) VALUES ("2",""2"",""1"",""1"",""1"",""1"",""1"","1","1","1","1","1","1","1",""1"",""1"",""1"",""1"",""1"",""1"","2017-07-04",""1"",""1"",""1"");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`) VALUES ("3",""3"",""1"",""1"",""1"",""1"",""1"","1","1","1","1","1","1","1",""1"",""1"",""1"",""1"",""1"",""1"","2017-07-04",""1"",""1"",""1"");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`) VALUES ("4",""4"",""1"",""1"",""1"",""1"",""1"","1","1","1","1","1","1","1",""1"",""1"",""1"",""1"",""1"",""1"","2017-07-04",""1"",""1"",""1"");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`) VALUES ("5",""4"",""1"",""1"",""1"",""1"",""1"","1","1","1","1","1","1","1",""1"",""1"",""1"",""1"",""1"",""1"","2017-07-04",""1"",""1"",""1"");



-- -----------------------------------------------------
-- Table `webMuseu`.`opcao`
-- -----------------------------------------------------

DROP TABLE IF EXISTS opcao;
CREATE TABLE `opcao` (
  `idOpcao` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(45) NOT NULL,
  PRIMARY KEY (`idOpcao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `opcao`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`pergunta`
-- -----------------------------------------------------

DROP TABLE IF EXISTS pergunta;
CREATE TABLE `pergunta` (
  `idPergunta` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(45) NOT NULL,
  `opcional` tinyint(1) NOT NULL,
  `tipo` enum('ABERTA','UNICA ESCOLHA','MULTIPLA ESCOLHA') NOT NULL,
  PRIMARY KEY (`idPergunta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `pergunta`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`perguntaopcao`
-- -----------------------------------------------------

DROP TABLE IF EXISTS perguntaopcao;
CREATE TABLE `perguntaopcao` (
  `idPergunta` int(11) NOT NULL,
  `idOpcao` int(11) NOT NULL,
  PRIMARY KEY (`idPergunta`,`idOpcao`),
  KEY `fk_PerguntaOpcao_Opcao_idx` (`idOpcao`),
  CONSTRAINT `fk_PerguntaOpcao_Opcao` FOREIGN KEY (`idOpcao`) REFERENCES `opcao` (`idOpcao`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_PerguntaOpcao_Pergunta` FOREIGN KEY (`idPergunta`) REFERENCES `pergunta` (`idPergunta`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `perguntaopcao`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`perguntapesquisa`
-- -----------------------------------------------------

DROP TABLE IF EXISTS perguntapesquisa;
CREATE TABLE `perguntapesquisa` (
  `idPergunta` int(11) NOT NULL,
  `idPesquisa` int(11) NOT NULL,
  PRIMARY KEY (`idPergunta`,`idPesquisa`),
  KEY `fk_PerguntaPesquisa_Pesquisa_idx` (`idPesquisa`),
  CONSTRAINT `fk_PerguntaPesquisa_Pergunta` FOREIGN KEY (`idPergunta`) REFERENCES `pergunta` (`idPergunta`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_PerguntaPesquisa_Pesquisa` FOREIGN KEY (`idPesquisa`) REFERENCES `pesquisa` (`idPesquisa`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `perguntapesquisa`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`pesquisa`
-- -----------------------------------------------------

DROP TABLE IF EXISTS pesquisa;
CREATE TABLE `pesquisa` (
  `idPesquisa` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(45) NOT NULL,
  `estaAtiva` tinyint(1) NOT NULL,
  PRIMARY KEY (`idPesquisa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `pesquisa`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`tag`
-- -----------------------------------------------------

DROP TABLE IF EXISTS tag;
CREATE TABLE `tag` (
  `idTag` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(45) NOT NULL,
  PRIMARY KEY (`idTag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `tag`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`tagobra`
-- -----------------------------------------------------

DROP TABLE IF EXISTS tagobra;
CREATE TABLE `tagobra` (
  `idTag` int(11) NOT NULL,
  `idObra` int(11) NOT NULL,
  PRIMARY KEY (`idTag`,`idObra`),
  KEY `fk_idObra_idx` (`idObra`),
  CONSTRAINT `fk_TagObra_Obra` FOREIGN KEY (`idObra`) REFERENCES `obra` (`numeroInventario`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_TagObra_Tag` FOREIGN KEY (`idTag`) REFERENCES `tag` (`idTag`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `tagobra`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`usuario`
-- -----------------------------------------------------

DROP TABLE IF EXISTS usuario;
CREATE TABLE `usuario` (
  `idUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(20) NOT NULL,
  `sobrenome` varchar(45) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `senha` varchar(50) DEFAULT NULL,
  `cadastroConfirmado` tinyint(1) NOT NULL,
  `tipoUsuario` enum('USUARIO','FUNCIONARIO','ADMINISTRADOR') DEFAULT NULL,
  PRIMARY KEY (`idUsuario`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `usuario`
--

INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("1","1","1","1","1","1","FUNCIONARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("2","2","1","2","1","1","FUNCIONARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("3","3","1","3","1","1","FUNCIONARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("4","4","1","4","1","1","FUNCIONARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("5","5","1","5","1","1","FUNCIONARIO");



-- -----------------------------------------------------
-- Table `webMuseu`.`usuarioacessoobra`
-- -----------------------------------------------------

DROP TABLE IF EXISTS usuarioacessoobra;
CREATE TABLE `usuarioacessoobra` (
  `numeroInventario` int(11) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  PRIMARY KEY (`idUsuario`,`numeroInventario`),
  KEY `fk_UsuarioAcesso_Usuario_idx` (`idUsuario`),
  KEY `fk_UsuarioAcesso_AcessoObra_idx` (`numeroInventario`),
  CONSTRAINT `fk_UsuarioAcesso_AcessoObra` FOREIGN KEY (`numeroInventario`) REFERENCES `obra` (`numeroInventario`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_UsuarioAcesso_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `usuarioacessoobra`
--

INSERT INTO usuarioacessoobra (`numeroInventario`,`idUsuario`) VALUES ("1","1");
INSERT INTO usuarioacessoobra (`numeroInventario`,`idUsuario`) VALUES ("3","1");
INSERT INTO usuarioacessoobra (`numeroInventario`,`idUsuario`) VALUES ("4","1");
INSERT INTO usuarioacessoobra (`numeroInventario`,`idUsuario`) VALUES ("1","2");
INSERT INTO usuarioacessoobra (`numeroInventario`,`idUsuario`) VALUES ("2","2");
INSERT INTO usuarioacessoobra (`numeroInventario`,`idUsuario`) VALUES ("1","3");



-- -----------------------------------------------------
-- Table `webMuseu`.`usuariofacebook`
-- -----------------------------------------------------

DROP TABLE IF EXISTS usuariofacebook;
CREATE TABLE `usuariofacebook` (
  `idUsuarioFacebook` varchar(50) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  PRIMARY KEY (`idUsuarioFacebook`),
  KEY `fk_UsuarioFacebook_Usuario_idx` (`idUsuario`),
  CONSTRAINT `fk_UsuarioFacebook_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `usuariofacebook`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`usuariogoogle`
-- -----------------------------------------------------

DROP TABLE IF EXISTS usuariogoogle;
CREATE TABLE `usuariogoogle` (
  `idUsuarioGoogle` varchar(50) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  PRIMARY KEY (`idUsuarioGoogle`),
  KEY `fk_UsuarioGoogle_Usuario_idx` (`idUsuario`),
  CONSTRAINT `fk_UsuarioGoogle_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `usuariogoogle`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`usuariorespostapesquisa`
-- -----------------------------------------------------

DROP TABLE IF EXISTS usuariorespostapesquisa;
CREATE TABLE `usuariorespostapesquisa` (
  `idUsuario` int(11) NOT NULL,
  `idPesquisa` int(11) NOT NULL,
  PRIMARY KEY (`idUsuario`,`idPesquisa`),
  KEY `fk_UsuarioRespostaPesquisa_Pesquisa_idx` (`idPesquisa`),
  CONSTRAINT `fk_UsuarioRespostaPesquisa_Pesquisa` FOREIGN KEY (`idPesquisa`) REFERENCES `pesquisa` (`idPesquisa`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_UsuarioRespostaPesquisa_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `usuariorespostapesquisa`
--




