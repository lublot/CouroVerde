-- pjl SQL Dump
-- Server version:5.7.14
-- Generated: 2017-08-03 12:14:14
-- Current PHP version: 7.0.10
-- localhost: localhost
-- Database:webMuseu
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema webMuseu
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `webMuseu` DEFAULT CHARACTER SET utf8 ;
USE `webMuseu` ;

-- -----------------------------------------------------
-- Table `webMuseu`.`arquivo`
-- -----------------------------------------------------

DROP TABLE IF EXISTS arquivo;
CREATE TABLE `arquivo` (
  `idArquivo` int(11) NOT NULL AUTO_INCREMENT,
  `caminho` varchar(200) NOT NULL,
  `tipo` enum('IMAGEM','MODELO3D','TEXTURA') NOT NULL,
  PRIMARY KEY (`idArquivo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `arquivo`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`arquivoobra`
-- -----------------------------------------------------

DROP TABLE IF EXISTS arquivoobra;
CREATE TABLE `arquivoobra` (
  `idObra` int(11) NOT NULL,
  `idArquivo` int(11) NOT NULL,
  PRIMARY KEY (`idObra`,`idArquivo`),
  KEY `fk_idArquivo_idx` (`idArquivo`),
  CONSTRAINT `fk_ArquivoObra_Arquivo` FOREIGN KEY (`idArquivo`) REFERENCES `arquivo` (`idArquivo`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ArquivoObra_Obra` FOREIGN KEY (`idObra`) REFERENCES `obra` (`numeroInventario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `arquivoobra`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`backup`
-- -----------------------------------------------------

DROP TABLE IF EXISTS backup;
CREATE TABLE `backup` (
  `idBackup` int(11) NOT NULL AUTO_INCREMENT,
  `caminho` varchar(200) NOT NULL,
  `dataHora` datetime NOT NULL,
  PRIMARY KEY (`idBackup`)
) ENGINE=InnoDB AUTO_INCREMENT=222 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `backup`
--

INSERT INTO backup (`idBackup`,`caminho`,`dataHora`) VALUES ("221","backups/backup_2017-08-0312-13-15.zip","2017-08-03 12:13:15");



-- -----------------------------------------------------
-- Table `webMuseu`.`classificacao`
-- -----------------------------------------------------

DROP TABLE IF EXISTS classificacao;
CREATE TABLE `classificacao` (
  `idClassificacao` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  PRIMARY KEY (`idClassificacao`),
  UNIQUE KEY `nome_UNIQUE` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `classificacao`
--

INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("26","amet, dapibus");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("5","amet, risus.");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("18","arcu. Vestibulum");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("39","consequat purus.");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("16","Donec egestas.");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("34","Donec est.");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("15","Donec tempus,");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("23","erat. Sed");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("29","fermentum convallis");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("33","imperdiet non,");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("20","In mi");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("12","ipsum. Suspendisse");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("9","laoreet, libero");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("13","libero. Morbi");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("40","litora torquent");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("8","magna. Nam");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("7","magnis dis");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("10","malesuada fames");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("28","mi tempor");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("21","montes, nascetur");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("31","nisl. Nulla");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("17","nulla ante,");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("36","Nullam enim.");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("11","orci tincidunt");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("24","penatibus et");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("6","Phasellus libero");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("19","Phasellus ornare.");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("37","posuere cubilia");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("25","primis in");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("35","pulvinar arcu");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("27","quis, pede.");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("22","rhoncus. Proin");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("32","Suspendisse commodo");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("1","ultrices iaculis");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("4","ultrices sit");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("30","venenatis lacus.");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("3","Vestibulum accumsan");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("2","vitae, aliquet");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("14","viverra. Donec");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("38","vulputate ullamcorper");



-- -----------------------------------------------------
-- Table `webMuseu`.`colecao`
-- -----------------------------------------------------

DROP TABLE IF EXISTS colecao;
CREATE TABLE `colecao` (
  `idColecao` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  PRIMARY KEY (`idColecao`),
  UNIQUE KEY `nome_UNIQUE` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `colecao`
--

INSERT INTO colecao (`idColecao`,`nome`) VALUES ("3","Alexa");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("12","Alfreda");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("11","Alika");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("35","Amity");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("34","Aubrey");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("7","Ava");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("19","Blossom");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("30","Brenna");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("20","Brooke");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("38","Charissa");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("24","Daphne");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("6","Deirdre");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("10","Diana");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("33","Eden");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("17","Evangeline");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("15","Eve");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("29","Fatima");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("8","Giselle");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("5","Hedwig");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("39","Helen");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("27","Hillary");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("36","Isadora");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("18","Jaime");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("14","Karen");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("22","Karleigh");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("4","Kirestin");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("9","Kyra");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("21","Lael");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("13","Maya");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("28","Melyssa");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("37","Mia");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("23","Orla");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("31","Quincy");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("26","Quynn");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("40","Shay");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("2","Suki");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("25","Vanna");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("32","Veda");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("1","Xena");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("16","Zephr");



-- -----------------------------------------------------
-- Table `webMuseu`.`fotografia`
-- -----------------------------------------------------

DROP TABLE IF EXISTS fotografia;
CREATE TABLE `fotografia` (
  `idFotografia` int(11) NOT NULL,
  `Fotografo` varchar(50) DEFAULT NULL,
  `data` date DEFAULT NULL,
  `autorFotografia` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`idFotografia`),
  CONSTRAINT `fk_Fotografia_Obra` FOREIGN KEY (`idFotografia`) REFERENCES `obra` (`numeroInventario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `fotografia`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`funcionario`
-- -----------------------------------------------------

DROP TABLE IF EXISTS funcionario;
CREATE TABLE `funcionario` (
  `matricula` int(11) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  `funcao` varchar(45) NOT NULL,
  `cadastroObra` tinyint(1) NOT NULL,
  `gerenciaObra` tinyint(1) NOT NULL,
  `remocaoObra` tinyint(1) NOT NULL,
  `cadastroNoticia` tinyint(1) NOT NULL,
  `gerenciaNoticia` tinyint(1) NOT NULL,
  `remocaoNoticia` tinyint(1) NOT NULL,
  `backup` tinyint(1) NOT NULL,
  PRIMARY KEY (`matricula`),
  UNIQUE KEY `idUsuario_UNIQUE` (`idUsuario`),
  KEY `fk_Funcionario_Usuario_idx` (`idUsuario`),
  CONSTRAINT `fk_Funcionario_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `funcionario`
--

INSERT INTO funcionario (`matricula`,`idUsuario`,`funcao`,`cadastroObra`,`gerenciaObra`,`remocaoObra`,`cadastroNoticia`,`gerenciaNoticia`,`remocaoNoticia`,`backup`) VALUES ("14211151","281","Something","1","0","0","0","0","0","0");
INSERT INTO funcionario (`matricula`,`idUsuario`,`funcao`,`cadastroObra`,`gerenciaObra`,`remocaoObra`,`cadastroNoticia`,`gerenciaNoticia`,`remocaoNoticia`,`backup`) VALUES ("15111215","270","Qualquer coisa","1","0","0","0","0","0","0");



-- -----------------------------------------------------
-- Table `webMuseu`.`logalteracoes`
-- -----------------------------------------------------

DROP TABLE IF EXISTS logalteracoes;
CREATE TABLE `logalteracoes` (
  `idLogAlteracoes` int(11) NOT NULL AUTO_INCREMENT,
  `matriculaFuncionario` int(11) NOT NULL,
  `idItemAlterado` int(11) NOT NULL,
  `tipoItemAlterado` enum('NOTICIA','OBRA','BACKUP','FUNCIONARIO') NOT NULL,
  `descricao` varchar(1000) NOT NULL,
  `dataHora` datetime NOT NULL,
  PRIMARY KEY (`idLogAlteracoes`),
  KEY `fk_LogAlteracoes_Funcionario_idx` (`matriculaFuncionario`),
  CONSTRAINT `fk_LogAlteracoes_Funcionario` FOREIGN KEY (`matriculaFuncionario`) REFERENCES `funcionario` (`matricula`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `logalteracoes`
--

INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("1","15111215","661","OBRA","Cadastrar pesquisa","2017-07-27 21:02:38");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("2","15111215","661","OBRA","Cadastrar pesquisa","2017-07-27 21:02:38");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("3","15111215","661","OBRA","Cadastrar pesquisa","2017-07-27 21:02:39");



-- -----------------------------------------------------
-- Table `webMuseu`.`noticia`
-- -----------------------------------------------------

DROP TABLE IF EXISTS noticia;
CREATE TABLE `noticia` (
  `idNoticia` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(50) NOT NULL,
  `subtitulo` varchar(100) DEFAULT NULL,
  `descricao` varchar(500) DEFAULT NULL,
  `caminhoImagem` varchar(200) DEFAULT NULL,
  `data` date NOT NULL,
  PRIMARY KEY (`idNoticia`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `noticia`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`obra`
-- -----------------------------------------------------

DROP TABLE IF EXISTS obra;
CREATE TABLE `obra` (
  `numeroInventario` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `funcao` varchar(45) DEFAULT NULL,
  `origem` varchar(45) DEFAULT NULL,
  `procedencia` varchar(45) DEFAULT NULL,
  `descricao` varchar(3000) DEFAULT NULL,
  `idColecao` int(11) NOT NULL,
  `idClassificacao` int(11) NOT NULL,
  `altura` float DEFAULT NULL,
  `largura` float DEFAULT NULL,
  `diametro` float DEFAULT NULL,
  `peso` float DEFAULT NULL,
  `comprimento` float DEFAULT NULL,
  `materiaisContruidos` varchar(200) DEFAULT NULL,
  `tecnicasFabricacao` varchar(100) DEFAULT NULL,
  `autoria` varchar(45) DEFAULT NULL,
  `marcasInscricoes` varchar(200) DEFAULT NULL,
  `historicoObjeto` varchar(200) DEFAULT NULL,
  `modoAquisicao` varchar(45) DEFAULT NULL,
  `dataAquisicao` date DEFAULT NULL,
  `autor` varchar(45) DEFAULT NULL,
  `observacoes` varchar(100) DEFAULT NULL,
  `estadoConservacao` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`numeroInventario`),
  KEY `idCategoria_idx` (`idClassificacao`),
  KEY `fk_idColecao_obra_idx` (`idColecao`),
  CONSTRAINT `fk_Obra_Classificacao` FOREIGN KEY (`idClassificacao`) REFERENCES `classificacao` (`idClassificacao`) ON UPDATE CASCADE,
  CONSTRAINT `fk_Obra_Colecao` FOREIGN KEY (`idColecao`) REFERENCES `colecao` (`idColecao`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `obra`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`opcao`
-- -----------------------------------------------------

DROP TABLE IF EXISTS opcao;
CREATE TABLE `opcao` (
  `idOpcao` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(45) NOT NULL,
  PRIMARY KEY (`idOpcao`)
) ENGINE=InnoDB AUTO_INCREMENT=2863 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `opcao`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`pergunta`
-- -----------------------------------------------------

DROP TABLE IF EXISTS pergunta;
CREATE TABLE `pergunta` (
  `idPergunta` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(45) NOT NULL,
  `opcional` tinyint(1) NOT NULL,
  `tipo` enum('ABERTA','UNICA ESCOLHA','MULTIPLA ESCOLHA') NOT NULL,
  PRIMARY KEY (`idPergunta`)
) ENGINE=InnoDB AUTO_INCREMENT=2117 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `pergunta`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`perguntaopcao`
-- -----------------------------------------------------

DROP TABLE IF EXISTS perguntaopcao;
CREATE TABLE `perguntaopcao` (
  `idPergunta` int(11) NOT NULL,
  `idOpcao` int(11) NOT NULL,
  PRIMARY KEY (`idPergunta`,`idOpcao`),
  KEY `fk_PerguntaOpcao_Opcao_idx` (`idOpcao`),
  CONSTRAINT `fk_PerguntaOpcao_Opcao` FOREIGN KEY (`idOpcao`) REFERENCES `opcao` (`idOpcao`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_PerguntaOpcao_Pergunta` FOREIGN KEY (`idPergunta`) REFERENCES `pergunta` (`idPergunta`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `perguntaopcao`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`perguntapesquisa`
-- -----------------------------------------------------

DROP TABLE IF EXISTS perguntapesquisa;
CREATE TABLE `perguntapesquisa` (
  `idPergunta` int(11) NOT NULL,
  `idPesquisa` int(11) NOT NULL,
  PRIMARY KEY (`idPergunta`,`idPesquisa`),
  KEY `fk_PerguntaPesquisa_Pesquisa_idx` (`idPesquisa`),
  CONSTRAINT `fk_PerguntaPesquisa_Pergunta` FOREIGN KEY (`idPergunta`) REFERENCES `pergunta` (`idPergunta`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_PerguntaPesquisa_Pesquisa` FOREIGN KEY (`idPesquisa`) REFERENCES `pesquisa` (`idPesquisa`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `perguntapesquisa`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`pesquisa`
-- -----------------------------------------------------

DROP TABLE IF EXISTS pesquisa;
CREATE TABLE `pesquisa` (
  `idPesquisa` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(45) NOT NULL,
  `descricao` varchar(200) DEFAULT NULL,
  `estaAtiva` tinyint(1) NOT NULL,
  PRIMARY KEY (`idPesquisa`),
  UNIQUE KEY `titulo_UNIQUE` (`titulo`)
) ENGINE=InnoDB AUTO_INCREMENT=673 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `pesquisa`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`tag`
-- -----------------------------------------------------

DROP TABLE IF EXISTS tag;
CREATE TABLE `tag` (
  `idTag` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(45) NOT NULL,
  PRIMARY KEY (`idTag`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `tag`
--

INSERT INTO tag (`idTag`,`descricao`) VALUES ("1","tag teste");



-- -----------------------------------------------------
-- Table `webMuseu`.`tagobra`
-- -----------------------------------------------------

DROP TABLE IF EXISTS tagobra;
CREATE TABLE `tagobra` (
  `idTag` int(11) NOT NULL,
  `idObra` int(11) NOT NULL,
  PRIMARY KEY (`idTag`,`idObra`),
  KEY `fk_idObra_idx` (`idObra`),
  CONSTRAINT `fk_TagObra_Obra` FOREIGN KEY (`idObra`) REFERENCES `obra` (`numeroInventario`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_TagObra_Tag` FOREIGN KEY (`idTag`) REFERENCES `tag` (`idTag`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `tagobra`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`usuario`
-- -----------------------------------------------------

DROP TABLE IF EXISTS usuario;
CREATE TABLE `usuario` (
  `idUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(20) NOT NULL,
  `sobrenome` varchar(45) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `senha` varchar(50) DEFAULT NULL,
  `cadastroConfirmado` tinyint(1) NOT NULL,
  `tipoUsuario` enum('USUARIO','FUNCIONARIO','ADMINISTRADOR') DEFAULT NULL,
  PRIMARY KEY (`idUsuario`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=316 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `usuario`
--

INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("269","Nome","Sobrenome","email@email.com","ff64a1c43498d955147518733ac88c7c","1","ADMINISTRADOR");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("270","Diego","Loureno","diegossl94@gmail.com","25d55ad283aa400af464c76d713c07ad","1","FUNCIONARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("271","Fulano Face","De Face","v@gmail.com","","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("272","Fulano Google","De Google","g@gmail.com","","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("273","Fulano","De Tal","vvalmeida96@gmail.com","1bbd886460827015e5d605ed44252251","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("274","Fulano","De Tal","t@gmail.com","1bbd886460827015e5d605ed44252251","0","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("281","Aloisio","Junior","kleyner2@hotmail.com","25d55ad283aa400af464c76d713c07ad","1","FUNCIONARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("300","Ionara","de Almeida","","","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("315","Valmir","Vinicius","naughtynaughtyweliketoparty@live.com","52ae1afec952b779782a47ce2c07cdc5","1","USUARIO");



-- -----------------------------------------------------
-- Table `webMuseu`.`usuarioacessoobra`
-- -----------------------------------------------------

DROP TABLE IF EXISTS usuarioacessoobra;
CREATE TABLE `usuarioacessoobra` (
  `numeroInventario` int(11) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  PRIMARY KEY (`idUsuario`,`numeroInventario`),
  KEY `fk_UsuarioAcesso_Usuario_idx` (`idUsuario`),
  KEY `fk_UsuarioAcesso_AcessoObra_idx` (`numeroInventario`),
  CONSTRAINT `fk_UsuarioAcesso_AcessoObra` FOREIGN KEY (`numeroInventario`) REFERENCES `obra` (`numeroInventario`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_UsuarioAcesso_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `usuarioacessoobra`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`usuariofacebook`
-- -----------------------------------------------------

DROP TABLE IF EXISTS usuariofacebook;
CREATE TABLE `usuariofacebook` (
  `idUsuarioFacebook` varchar(50) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  PRIMARY KEY (`idUsuarioFacebook`),
  KEY `fk_UsuarioFacebook_Usuario_idx` (`idUsuario`),
  CONSTRAINT `fk_UsuarioFacebook_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `usuariofacebook`
--

INSERT INTO usuariofacebook (`idUsuarioFacebook`,`idUsuario`) VALUES ("8181818181","271");
INSERT INTO usuariofacebook (`idUsuarioFacebook`,`idUsuario`) VALUES ("1742030152480823","300");



-- -----------------------------------------------------
-- Table `webMuseu`.`usuariogoogle`
-- -----------------------------------------------------

DROP TABLE IF EXISTS usuariogoogle;
CREATE TABLE `usuariogoogle` (
  `idUsuarioGoogle` varchar(50) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  PRIMARY KEY (`idUsuarioGoogle`),
  KEY `fk_UsuarioGoogle_Usuario_idx` (`idUsuario`),
  CONSTRAINT `fk_UsuarioGoogle_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `usuariogoogle`
--

INSERT INTO usuariogoogle (`idUsuarioGoogle`,`idUsuario`) VALUES ("88238328","272");



-- -----------------------------------------------------
-- Table `webMuseu`.`usuariorespostapesquisa`
-- -----------------------------------------------------

DROP TABLE IF EXISTS usuariorespostapesquisa;
CREATE TABLE `usuariorespostapesquisa` (
  `idUsuario` int(11) NOT NULL,
  `idPesquisa` int(11) NOT NULL,
  PRIMARY KEY (`idUsuario`,`idPesquisa`),
  KEY `fk_UsuarioRespostaPesquisa_Pesquisa_idx` (`idPesquisa`),
  CONSTRAINT `fk_UsuarioRespostaPesquisa_Pesquisa` FOREIGN KEY (`idPesquisa`) REFERENCES `pesquisa` (`idPesquisa`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_UsuarioRespostaPesquisa_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `usuariorespostapesquisa`
--




