-- pjl SQL Dump
-- Server version:5.7.14
-- Generated: 2017-08-23 10:51:34
-- Current PHP version: 7.0.10
-- localhost: localhost
-- Database:webMuseu
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema webMuseu
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `webMuseu` DEFAULT CHARACTER SET utf8 ;
USE `webMuseu` ;

-- -----------------------------------------------------
-- Table `webMuseu`.`backup`
-- -----------------------------------------------------

DROP TABLE IF EXISTS backup;
CREATE TABLE `backup` (
  `idBackup` int(11) NOT NULL AUTO_INCREMENT,
  `caminho` text NOT NULL,
  `dataHora` datetime NOT NULL,
  PRIMARY KEY (`idBackup`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `backup`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`classificacao`
-- -----------------------------------------------------

DROP TABLE IF EXISTS classificacao;
CREATE TABLE `classificacao` (
  `idClassificacao` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  PRIMARY KEY (`idClassificacao`),
  UNIQUE KEY `nome_UNIQUE` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `classificacao`
--

INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("2","acervo madeira");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("53","bbb");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("52","cla");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("51","clasnova");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("54","dddd");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("50","novaclass");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("3","Objetos");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("49","Objetos de Casa");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("6","Objetos Pessoais");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("55","ooooo");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("1","periodo escravo");



-- -----------------------------------------------------
-- Table `webMuseu`.`colecao`
-- -----------------------------------------------------

DROP TABLE IF EXISTS colecao;
CREATE TABLE `colecao` (
  `idColecao` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  PRIMARY KEY (`idColecao`),
  UNIQUE KEY `nome_UNIQUE` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `colecao`
--

INSERT INTO colecao (`idColecao`,`nome`) VALUES ("3","Caricaturas");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("6","Chapus");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("5","Ferros");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("73","kkkk");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("67","lucas da feira");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("66","Luminrias");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("68","nova");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("69","novaaa");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("1","Pote");



-- -----------------------------------------------------
-- Table `webMuseu`.`fotografia`
-- -----------------------------------------------------

DROP TABLE IF EXISTS fotografia;
CREATE TABLE `fotografia` (
  `idFotografia` int(11) NOT NULL,
  `Fotografo` varchar(50) DEFAULT NULL,
  `data` date DEFAULT NULL,
  `autorFotografia` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`idFotografia`),
  CONSTRAINT `fk_Fotografia_Obra` FOREIGN KEY (`idFotografia`) REFERENCES `obra` (`numeroInventario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `fotografia`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`funcionario`
-- -----------------------------------------------------

DROP TABLE IF EXISTS funcionario;
CREATE TABLE `funcionario` (
  `matricula` int(11) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  `funcao` varchar(45) NOT NULL,
  `cadastroObra` tinyint(1) NOT NULL,
  `gerenciaObra` tinyint(1) NOT NULL,
  `remocaoObra` tinyint(1) NOT NULL,
  `cadastroNoticia` tinyint(1) NOT NULL,
  `gerenciaNoticia` tinyint(1) NOT NULL,
  `remocaoNoticia` tinyint(1) NOT NULL,
  `backup` tinyint(1) NOT NULL,
  PRIMARY KEY (`matricula`),
  UNIQUE KEY `idUsuario_UNIQUE` (`idUsuario`),
  KEY `fk_Funcionario_Usuario_idx` (`idUsuario`),
  CONSTRAINT `fk_Funcionario_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `funcionario`
--

INSERT INTO funcionario (`matricula`,`idUsuario`,`funcao`,`cadastroObra`,`gerenciaObra`,`remocaoObra`,`cadastroNoticia`,`gerenciaNoticia`,`remocaoNoticia`,`backup`) VALUES ("3","6","gerente back end","1","1","1","1","1","1","1");
INSERT INTO funcionario (`matricula`,`idUsuario`,`funcao`,`cadastroObra`,`gerenciaObra`,`remocaoObra`,`cadastroNoticia`,`gerenciaNoticia`,`remocaoNoticia`,`backup`) VALUES ("4","4","gerente geral","1","1","1","1","1","1","1");
INSERT INTO funcionario (`matricula`,`idUsuario`,`funcao`,`cadastroObra`,`gerenciaObra`,`remocaoObra`,`cadastroNoticia`,`gerenciaNoticia`,`remocaoNoticia`,`backup`) VALUES ("5","5","gerente front end","1","1","1","1","1","1","1");
INSERT INTO funcionario (`matricula`,`idUsuario`,`funcao`,`cadastroObra`,`gerenciaObra`,`remocaoObra`,`cadastroNoticia`,`gerenciaNoticia`,`remocaoNoticia`,`backup`) VALUES ("112233","1","Dona","1","1","1","1","1","1","1");
INSERT INTO funcionario (`matricula`,`idUsuario`,`funcao`,`cadastroObra`,`gerenciaObra`,`remocaoObra`,`cadastroNoticia`,`gerenciaNoticia`,`remocaoNoticia`,`backup`) VALUES ("445566","3","Funcionrio","1","1","1","0","0","0","1");



-- -----------------------------------------------------
-- Table `webMuseu`.`logalteracoes`
-- -----------------------------------------------------

DROP TABLE IF EXISTS logalteracoes;
CREATE TABLE `logalteracoes` (
  `idLogAlteracoes` int(11) NOT NULL AUTO_INCREMENT,
  `matriculaFuncionario` int(11) NOT NULL,
  `idItemAlterado` int(11) NOT NULL,
  `tipoItemAlterado` enum('NOTICIA','OBRA','BACKUP','FUNCIONARIO') NOT NULL,
  `descricao` text NOT NULL,
  `dataHora` datetime NOT NULL,
  PRIMARY KEY (`idLogAlteracoes`),
  KEY `fk_LogAlteracoes_Funcionario_idx` (`matriculaFuncionario`),
  CONSTRAINT `fk_LogAlteracoes_Funcionario` FOREIGN KEY (`matriculaFuncionario`) REFERENCES `funcionario` (`matricula`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `logalteracoes`
--

INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("1","5","6","OBRA","Uma obra foi alterada","2017-08-22 22:45:32");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("2","5","6","OBRA","Uma obra foi alterada","2017-08-22 22:46:52");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("3","5","8","OBRA","Uma obra foi cadastrada","2017-08-22 22:50:54");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("4","4","8","OBRA","Uma obra foi removida","2017-08-22 22:56:54");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("5","4","7","OBRA","Uma obra foi cadastrada","2017-08-22 22:59:58");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("6","112233","8888","OBRA","Uma obra foi cadastrada","2017-08-23 09:21:37");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("7","112233","8888","OBRA","Uma obra foi cadastrada","2017-08-23 09:23:51");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("8","112233","8888","OBRA","Uma obra foi cadastrada","2017-08-23 09:24:07");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("9","112233","8888","OBRA","Uma obra foi cadastrada","2017-08-23 09:24:22");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("10","112233","8888","OBRA","Uma obra foi cadastrada","2017-08-23 09:24:31");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("11","112233","8888","OBRA","Uma obra foi cadastrada","2017-08-23 09:24:36");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("12","112233","8888","OBRA","Uma obra foi cadastrada","2017-08-23 09:25:01");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("13","112233","8888","OBRA","Uma obra foi cadastrada","2017-08-23 09:25:07");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("14","112233","8888","OBRA","Uma obra foi cadastrada","2017-08-23 09:25:38");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("15","112233","8888","OBRA","Uma obra foi cadastrada","2017-08-23 09:25:44");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("16","112233","8888","OBRA","Uma obra foi cadastrada","2017-08-23 09:25:46");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("17","112233","4535","OBRA","Uma obra foi cadastrada","2017-08-23 09:26:09");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("18","112233","34455","OBRA","Uma obra foi cadastrada","2017-08-23 09:28:34");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("19","112233","77347","OBRA","Uma obra foi cadastrada","2017-08-23 09:29:51");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("20","112233","89894","OBRA","Uma obra foi cadastrada","2017-08-23 09:32:49");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("21","112233","5564","OBRA","Uma obra foi cadastrada","2017-08-23 09:38:07");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("22","112233","4656","OBRA","Uma obra foi cadastrada","2017-08-23 09:43:28");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("23","112233","4656","OBRA","Uma obra foi cadastrada","2017-08-23 09:44:06");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("24","112233","4656","OBRA","Uma obra foi cadastrada","2017-08-23 09:44:23");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("25","112233","4656","OBRA","Uma obra foi cadastrada","2017-08-23 09:44:40");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("26","112233","4656","OBRA","Uma obra foi cadastrada","2017-08-23 09:44:51");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("27","112233","4656","OBRA","Uma obra foi cadastrada","2017-08-23 09:45:25");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("28","112233","4656","OBRA","Uma obra foi cadastrada","2017-08-23 09:45:59");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("29","112233","4656","OBRA","Uma obra foi cadastrada","2017-08-23 09:46:38");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("30","112233","4656","OBRA","Uma obra foi cadastrada","2017-08-23 09:46:56");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("31","112233","4656","OBRA","Uma obra foi cadastrada","2017-08-23 09:47:10");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("32","112233","44523","OBRA","Uma obra foi cadastrada","2017-08-23 09:55:32");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("33","112233","8898","OBRA","Uma obra foi cadastrada","2017-08-23 10:03:01");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("34","112233","8898","OBRA","Uma obra foi cadastrada","2017-08-23 10:03:01");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("35","112233","4535","OBRA","Uma obra foi alterada","2017-08-23 10:06:11");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("36","112233","2","OBRA","Uma obra foi alterada","2017-08-23 10:06:26");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("37","112233","2","OBRA","Uma obra foi alterada","2017-08-23 10:15:11");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("38","112233","2","OBRA","Uma obra foi alterada","2017-08-23 10:15:26");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("39","112233","2","OBRA","Uma obra foi alterada","2017-08-23 10:15:40");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("40","112233","2","OBRA","Uma obra foi alterada","2017-08-23 10:15:51");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("41","112233","2","OBRA","Uma obra foi alterada","2017-08-23 10:17:59");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("42","112233","2","OBRA","Uma obra foi alterada","2017-08-23 10:19:18");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("43","112233","2","OBRA","Uma obra foi alterada","2017-08-23 10:19:52");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("44","112233","2","OBRA","Uma obra foi alterada","2017-08-23 10:23:16");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("45","112233","2","OBRA","Uma obra foi alterada","2017-08-23 10:35:54");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("46","112233","2","OBRA","Uma obra foi alterada","2017-08-23 10:36:08");



-- -----------------------------------------------------
-- Table `webMuseu`.`noticia`
-- -----------------------------------------------------

DROP TABLE IF EXISTS noticia;
CREATE TABLE `noticia` (
  `idNoticia` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(150) NOT NULL,
  `subtitulo` varchar(150) DEFAULT NULL,
  `descricao` text,
  `caminhoImagem` text,
  `data` date NOT NULL,
  PRIMARY KEY (`idNoticia`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `noticia`
--

INSERT INTO noticia (`idNoticia`,`titulo`,`subtitulo`,`descricao`,`caminhoImagem`,`data`) VALUES ("1","Inaugurao Web Museu Casa do Serto","","O web museu casa do serto foi inaugurado no dia 23/08/2017, desenvolvido pela MITHOLOGIC Software. O nome escolhido foi SERTOUR.","media/noticias/imagens/20170821172133museo_casa_certao_1.jpg","2017-08-22");
INSERT INTO noticia (`idNoticia`,`titulo`,`subtitulo`,`descricao`,`caminhoImagem`,`data`) VALUES ("2","Nova coleo no Museu Casa do Serto","","O web museu casa do serto inaugurou uma nova coleo no dia 22/08/2017, nessa nova coleo esto expostos diversos tipos de mquinas.","media/noticias/imagens/20170821172456museo_casa_certao_2.jpg","2017-08-22");



-- -----------------------------------------------------
-- Table `webMuseu`.`obra`
-- -----------------------------------------------------

DROP TABLE IF EXISTS obra;
CREATE TABLE `obra` (
  `numeroInventario` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `funcao` varchar(45) DEFAULT NULL,
  `origem` varchar(45) DEFAULT NULL,
  `procedencia` varchar(45) DEFAULT NULL,
  `descricao` text,
  `idColecao` int(11) NOT NULL,
  `idClassificacao` int(11) NOT NULL,
  `altura` float DEFAULT NULL,
  `largura` float DEFAULT NULL,
  `diametro` float DEFAULT NULL,
  `peso` float DEFAULT NULL,
  `comprimento` float DEFAULT NULL,
  `materiaisContruidos` varchar(200) DEFAULT NULL,
  `tecnicasFabricacao` varchar(100) DEFAULT NULL,
  `autoria` varchar(45) DEFAULT NULL,
  `marcasInscricoes` varchar(200) DEFAULT NULL,
  `historicoObjeto` varchar(200) DEFAULT NULL,
  `modoAquisicao` varchar(45) DEFAULT NULL,
  `dataAquisicao` date DEFAULT NULL,
  `autor` varchar(45) DEFAULT NULL,
  `observacoes` varchar(100) DEFAULT NULL,
  `estadoConservacao` varchar(45) DEFAULT NULL,
  `caminhoImagem1` text,
  `caminhoImagem2` text,
  `caminhoImagem3` text,
  `caminhoImagem4` text,
  `caminhoImagem5` text,
  `caminhoModelo3D` text,
  PRIMARY KEY (`numeroInventario`),
  KEY `idCategoria_idx` (`idClassificacao`),
  KEY `fk_idColecao_obra_idx` (`idColecao`),
  CONSTRAINT `fk_Obra_Classificacao` FOREIGN KEY (`idClassificacao`) REFERENCES `classificacao` (`idClassificacao`) ON UPDATE CASCADE,
  CONSTRAINT `fk_Obra_Colecao` FOREIGN KEY (`idColecao`) REFERENCES `colecao` (`idColecao`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `obra`
--

INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("1","Luminria","Luminria sertaneja tpica","","Serto da Bahia","","Uma luminria tpica do serto da bahia.","66","49","1.5","2","3","4","10","Plstico e couro","Vrias","Desconhecido","Alguns arranhes","","","","","","","../media/obras/imagens/1/luminaria-rustica-de-juta-e-resina-chacaras.jpg","../media/obras/imagens/1/lu-potes.jpg","","","","../media/obras/modelo3d/1/lamp.obj");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("2","Pote","Pote sertanejo t???pico","","Feira de Santana","","Um pote tpico do serto da bahia.","1","6","1.5","2","3","4","10","Cermica","Vrias","Desconhecido","Alguns arranhes","","","","","","","../media/obras/imagens/2/pote.jpg","","","","","../media/obras/modelo3d/2/pote.obj");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("3","Rosto Asssustado","Rosto Asssustado do Serto","","Serto da Bahia","","Uma caricatura tpica do serto da bahia.","3","3","1.5","2","3","4","10","Cermica","Vrias","Desconhecido","Alguns arranhes","","","","","","","../media/obras/imagens/3/caricatura.jpg","","","","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("4","Chapu Tpico","Chapu Tpico de Sertanejo","","Serto da Bahia","","Um chapu tpico do serto da bahia.","6","6","1.5","2","3","4","10","Couro","Vrias","Desconhecido","Alguns arranhes","","","","","","","../media/obras/imagens/4/chapeu.jpg","","","","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("5","Ferro de Passar Roupa","Ferro de Passar Roupa Carvo","","Serto da Bahia","","Um ferro de passar tpico do serto da bahia.","5","49","1.5","2","3","4","10","Ferro e carvo","Vrias","Desconhecido","Alguns arranhes","","","","","","","../media/obras/imagens/5/f1.jpg","../media/obras/imagens/5/f2.jpg","","","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("6","Carro de boi","Carro de boi","","","","","1","1","","","","","","","","","","","","","","","","../media/obras/imagens/6/IMG-20170822-WA0008.jpg","../media/obras/imagens/6/carro de boi.jpg","","","","../media/obras/modelo3d/6/carroca.obj");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("7","Tear","Tear","","","","","67","49","","","","","","","","","","","","","","","","../media/obras/imagens/7/Tear.jpg","","","","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("4535","dSSFDFDS","FDSFSDFDS","","","","","5","1","","","","","","","","","","","","","","","","../media/obras/imagens/4535/1.jpg","../media/obras/imagens/4535/icone.png","../media/obras/imagens/4535/tumblr_ouznfomxAp1tcumyko1_1280.png","../media/obras/imagens/4535/.gif","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("8898","nothing","but respect","","","","","1","1","","","","","","","","","","","","","","","","../media/obras/imagens/8898/1.jpg","../media/obras/imagens/8898/tumblr_ouznfomxAp1tcumyko1_1280.png","","","","../media/obras/modelo3d/8898/ironman.obj");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("34455","FSDSFDFSD","FDFDFD","","","","","5","3","","","","","","","","","","","","","","","","../media/obras/imagens/34455/1.jpg","../media/obras/imagens/34455/icone.png","../media/obras/imagens/34455/tumblr_ouznfomxAp1tcumyko1_1280.png","../media/obras/imagens/34455/.gif","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("44523","ojfdjdkskf","dkjjfdfdlk","","","","","73","55","","","","","","","","","","","","","","","","../media/obras/imagens/44523/1.jpg","","","","","");



-- -----------------------------------------------------
-- Table `webMuseu`.`opcao`
-- -----------------------------------------------------

DROP TABLE IF EXISTS opcao;
CREATE TABLE `opcao` (
  `idOpcao` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` text NOT NULL,
  PRIMARY KEY (`idOpcao`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `opcao`
--

INSERT INTO opcao (`idOpcao`,`descricao`) VALUES ("1","no");
INSERT INTO opcao (`idOpcao`,`descricao`) VALUES ("2","sim");
INSERT INTO opcao (`idOpcao`,`descricao`) VALUES ("3","muito");
INSERT INTO opcao (`idOpcao`,`descricao`) VALUES ("4","pagina inicial");
INSERT INTO opcao (`idOpcao`,`descricao`) VALUES ("5","galeria");
INSERT INTO opcao (`idOpcao`,`descricao`) VALUES ("6","sobre");
INSERT INTO opcao (`idOpcao`,`descricao`) VALUES ("7","filtro");
INSERT INTO opcao (`idOpcao`,`descricao`) VALUES ("8","noticias");



-- -----------------------------------------------------
-- Table `webMuseu`.`pergunta`
-- -----------------------------------------------------

DROP TABLE IF EXISTS pergunta;
CREATE TABLE `pergunta` (
  `idPergunta` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` text NOT NULL,
  `opcional` tinyint(1) NOT NULL,
  `tipo` enum('ABERTA','UNICA ESCOLHA','MULTIPLA ESCOLHA') NOT NULL,
  PRIMARY KEY (`idPergunta`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `pergunta`
--

INSERT INTO pergunta (`idPergunta`,`titulo`,`opcional`,`tipo`) VALUES ("1","Est satisfeito com sistema?","0","UNICA ESCOLHA");
INSERT INTO pergunta (`idPergunta`,`titulo`,`opcional`,`tipo`) VALUES ("2","O que gostou?","0","MULTIPLA ESCOLHA");
INSERT INTO pergunta (`idPergunta`,`titulo`,`opcional`,`tipo`) VALUES ("3","Escreva aqui uma sugesto","1","ABERTA");



-- -----------------------------------------------------
-- Table `webMuseu`.`perguntaopcao`
-- -----------------------------------------------------

DROP TABLE IF EXISTS perguntaopcao;
CREATE TABLE `perguntaopcao` (
  `idPergunta` int(11) NOT NULL,
  `idOpcao` int(11) NOT NULL,
  PRIMARY KEY (`idPergunta`,`idOpcao`),
  KEY `fk_PerguntaOpcao_Opcao_idx` (`idOpcao`),
  CONSTRAINT `fk_PerguntaOpcao_Opcao` FOREIGN KEY (`idOpcao`) REFERENCES `opcao` (`idOpcao`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_PerguntaOpcao_Pergunta` FOREIGN KEY (`idPergunta`) REFERENCES `pergunta` (`idPergunta`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `perguntaopcao`
--

INSERT INTO perguntaopcao (`idPergunta`,`idOpcao`) VALUES ("1","1");
INSERT INTO perguntaopcao (`idPergunta`,`idOpcao`) VALUES ("1","2");
INSERT INTO perguntaopcao (`idPergunta`,`idOpcao`) VALUES ("1","3");
INSERT INTO perguntaopcao (`idPergunta`,`idOpcao`) VALUES ("2","4");
INSERT INTO perguntaopcao (`idPergunta`,`idOpcao`) VALUES ("2","5");
INSERT INTO perguntaopcao (`idPergunta`,`idOpcao`) VALUES ("2","6");
INSERT INTO perguntaopcao (`idPergunta`,`idOpcao`) VALUES ("2","7");
INSERT INTO perguntaopcao (`idPergunta`,`idOpcao`) VALUES ("2","8");



-- -----------------------------------------------------
-- Table `webMuseu`.`perguntapesquisa`
-- -----------------------------------------------------

DROP TABLE IF EXISTS perguntapesquisa;
CREATE TABLE `perguntapesquisa` (
  `idPergunta` int(11) NOT NULL,
  `idPesquisa` int(11) NOT NULL,
  PRIMARY KEY (`idPergunta`,`idPesquisa`),
  KEY `fk_PerguntaPesquisa_Pesquisa_idx` (`idPesquisa`),
  CONSTRAINT `fk_PerguntaPesquisa_Pergunta` FOREIGN KEY (`idPergunta`) REFERENCES `pergunta` (`idPergunta`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_PerguntaPesquisa_Pesquisa` FOREIGN KEY (`idPesquisa`) REFERENCES `pesquisa` (`idPesquisa`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `perguntapesquisa`
--

INSERT INTO perguntapesquisa (`idPergunta`,`idPesquisa`) VALUES ("1","1");
INSERT INTO perguntapesquisa (`idPergunta`,`idPesquisa`) VALUES ("2","1");
INSERT INTO perguntapesquisa (`idPergunta`,`idPesquisa`) VALUES ("3","1");



-- -----------------------------------------------------
-- Table `webMuseu`.`pesquisa`
-- -----------------------------------------------------

DROP TABLE IF EXISTS pesquisa;
CREATE TABLE `pesquisa` (
  `idPesquisa` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(150) NOT NULL,
  `descricao` text,
  `estaAtiva` tinyint(1) NOT NULL,
  PRIMARY KEY (`idPesquisa`),
  UNIQUE KEY `titulo_UNIQUE` (`titulo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `pesquisa`
--

INSERT INTO pesquisa (`idPesquisa`,`titulo`,`descricao`,`estaAtiva`) VALUES ("1","Pesquisa de satisfao do sistema","Essa pesquisa visa buscar estatsticas em relao ao uso do sistema.","1");



-- -----------------------------------------------------
-- Table `webMuseu`.`respostaaberta`
-- -----------------------------------------------------

DROP TABLE IF EXISTS respostaaberta;
CREATE TABLE `respostaaberta` (
  `idUsuario` int(11) NOT NULL,
  `idPesquisa` int(11) NOT NULL,
  `idPergunta` int(11) NOT NULL,
  `descricao` text NOT NULL,
  PRIMARY KEY (`idUsuario`,`idPesquisa`,`idPergunta`),
  KEY `fk_RespostaAberta_Pergunta_idx` (`idPergunta`),
  KEY `fk_RespostaAberta_Pesquisa_idx` (`idPesquisa`),
  CONSTRAINT `fk_RespostaAberta_Pergunta` FOREIGN KEY (`idPergunta`) REFERENCES `pergunta` (`idPergunta`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_RespostaAberta_Pesquisa` FOREIGN KEY (`idPesquisa`) REFERENCES `pesquisa` (`idPesquisa`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_RespostaAberta_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `respostaaberta`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`respostafechada`
-- -----------------------------------------------------

DROP TABLE IF EXISTS respostafechada;
CREATE TABLE `respostafechada` (
  `idUsuario` int(11) NOT NULL,
  `idPesquisa` int(11) NOT NULL,
  `idPergunta` int(11) NOT NULL,
  `idOpcao` int(11) NOT NULL,
  PRIMARY KEY (`idUsuario`,`idPesquisa`,`idPergunta`,`idOpcao`),
  KEY `fk_RespostaSelecionada_Opcao_idx` (`idOpcao`),
  KEY `fk_RespostaFechada_Pergunta_idx` (`idPergunta`),
  KEY `fk_RespostaFechada_Pesquisa_idx` (`idPesquisa`),
  CONSTRAINT `fk_RespostaFechada_Opcao` FOREIGN KEY (`idOpcao`) REFERENCES `opcao` (`idOpcao`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_RespostaFechada_Pergunta` FOREIGN KEY (`idPergunta`) REFERENCES `pergunta` (`idPergunta`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_RespostaFechada_Pesquisa` FOREIGN KEY (`idPesquisa`) REFERENCES `pesquisa` (`idPesquisa`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_RespostaFechada_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `respostafechada`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`tag`
-- -----------------------------------------------------

DROP TABLE IF EXISTS tag;
CREATE TABLE `tag` (
  `idTag` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(45) NOT NULL,
  PRIMARY KEY (`idTag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `tag`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`tagobra`
-- -----------------------------------------------------

DROP TABLE IF EXISTS tagobra;
CREATE TABLE `tagobra` (
  `idTag` int(11) NOT NULL,
  `idObra` int(11) NOT NULL,
  PRIMARY KEY (`idTag`,`idObra`),
  KEY `fk_idObra_idx` (`idObra`),
  CONSTRAINT `fk_TagObra_Obra` FOREIGN KEY (`idObra`) REFERENCES `obra` (`numeroInventario`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_TagObra_Tag` FOREIGN KEY (`idTag`) REFERENCES `tag` (`idTag`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `tagobra`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`usuario`
-- -----------------------------------------------------

DROP TABLE IF EXISTS usuario;
CREATE TABLE `usuario` (
  `idUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(20) NOT NULL,
  `sobrenome` varchar(45) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `senha` varchar(50) DEFAULT NULL,
  `cadastroConfirmado` tinyint(1) NOT NULL,
  `tipoUsuario` enum('USUARIO','FUNCIONARIO','ADMINISTRADOR') DEFAULT NULL,
  PRIMARY KEY (`idUsuario`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `usuario`
--

INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("1","Jamylle","Santana","jamyllesf@gmail.com","25d55ad283aa400af464c76d713c07ad","1","ADMINISTRADOR");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("2","Usurio","Comum","usuariocomum@gmail.com","2e9ec317e197819358fbc43afca7d837","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("3","Funcionrio","Museu","funcionariomuseu@gmail.com","551b50cd77c369891fa02b5dc73c03a7","1","FUNCIONARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("4","valmir","vinicius","vvalmeida96@gmail.com","e7d80ffeefa212b7c5c55700e4f7193e","1","ADMINISTRADOR");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("5","sarah","pereira","sarahecomp@gmail.com","e7d80ffeefa212b7c5c55700e4f7193e","1","FUNCIONARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("6","emerson","souza","ebssoueu@gmail.com","e7d80ffeefa212b7c5c55700e4f7193e","1","FUNCIONARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("7","emerson","santos","emersonsl1605@gmail.com","e7d80ffeefa212b7c5c55700e4f7193e","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("8","Alosio","Jnior","kleyner2@hotmail.com","e7d80ffeefa212b7c5c55700e4f7193e","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("9","Bruno","Menezes","brunomenezes253@gmail.com","e7d80ffeefa212b7c5c55700e4f7193e","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("10","iago","macedo","iagomcd.almeida@gmail.com ","e7d80ffeefa212b7c5c55700e4f7193e","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("11","marcus","aldrey","marcusaldrey@gmail.com","e7d80ffeefa212b7c5c55700e4f7193e","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("12","Matheus","Texeira","mteixeira.1998@gmail.com","e7d80ffeefa212b7c5c55700e4f7193e","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("13","victor","munduruca","victormunduruca@gmail.com","e7d80ffeefa212b7c5c55700e4f7193e","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("14","diego","loureno","diegossl94@gmail.com","e7d80ffeefa212b7c5c55700e4f7193e","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("15","joao","silva","joao@silva.com","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("16","Ryder","Maddox","vestibulum@erat.ca","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("17","Sawyer","Munoz","dictum@ipsumdolorsit.edu","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("18","Neville","Rollins","sed.dolor@estNunc.co.uk","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("19","Connor","Sparks","Nam.interdum@risus.co.uk","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("20","Garth","Yang","dolor.sit.amet@amet.com","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("21","Harper","Fernandez","dolor.sit@Loremipsum.edu","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("22","Lev","Serrano","mauris@ac.ca","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("23","Gage","Stein","urna@Aliquamfringilla.edu","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("24","Jacob","Weber","iaculis.enim@sapienmolestieorci.co.uk","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("25","Christopher","Cannon","vitae.mauris.sit@auctor.co.uk","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("26","Hakeem","May","Nulla.facilisi.Sed@ligula.com","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("27","Damon","Mcpherson","ornare.lectus@hymenaeosMauris.edu","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("28","Erasmus","David","libero.mauris@dictum.edu","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("29","Akeem","Tyler","neque@posuereenim.net","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("30","Burton","Walters","erat.vitae@Morbiaccumsanlaoreet.com","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("31","Kasper","Le","pharetra.sed@sagittisaugue.ca","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("32","Edan","Collins","nunc@euismod.org","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("33","Rogan","Terrell","sit@idrisus.co.uk","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("34","Blaze","Shelton","augue@vitaemaurissit.ca","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("35","Forrest","Avila","hendrerit.a@Maecenas.net","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("36","Paki","Pennington","mauris.sit@arcuNunc.ca","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("37","Arthur","Moss","Curabitur.dictum.Phasellus@nibhsit.ca","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("38","Grant","Crawford","vulputate@Cras.net","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("39","Reuben","Potts","Maecenas.mi.felis@actellusSuspendisse.edu","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("40","David","Lloyd","lobortis.quis.pede@hendrerit.co.uk","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("41","Merrill","Wong","facilisis.eget.ipsum@sodalesnisi.org","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("42","Raphael","Finch","elit.pretium@turpisvitae.ca","732002cec7aeb7987bde842b9e00ee3b","1","USUARIO");



-- -----------------------------------------------------
-- Table `webMuseu`.`usuarioacessoobra`
-- -----------------------------------------------------

DROP TABLE IF EXISTS usuarioacessoobra;
CREATE TABLE `usuarioacessoobra` (
  `numeroInventario` int(11) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  PRIMARY KEY (`idUsuario`,`numeroInventario`),
  KEY `fk_UsuarioAcesso_Usuario_idx` (`idUsuario`),
  KEY `fk_UsuarioAcesso_AcessoObra_idx` (`numeroInventario`),
  CONSTRAINT `fk_UsuarioAcesso_AcessoObra` FOREIGN KEY (`numeroInventario`) REFERENCES `obra` (`numeroInventario`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_UsuarioAcesso_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `usuarioacessoobra`
--

INSERT INTO usuarioacessoobra (`numeroInventario`,`idUsuario`) VALUES ("1","1");
INSERT INTO usuarioacessoobra (`numeroInventario`,`idUsuario`) VALUES ("2","1");
INSERT INTO usuarioacessoobra (`numeroInventario`,`idUsuario`) VALUES ("3","1");
INSERT INTO usuarioacessoobra (`numeroInventario`,`idUsuario`) VALUES ("5","1");
INSERT INTO usuarioacessoobra (`numeroInventario`,`idUsuario`) VALUES ("6","1");
INSERT INTO usuarioacessoobra (`numeroInventario`,`idUsuario`) VALUES ("7","1");
INSERT INTO usuarioacessoobra (`numeroInventario`,`idUsuario`) VALUES ("8898","1");
INSERT INTO usuarioacessoobra (`numeroInventario`,`idUsuario`) VALUES ("34455","1");
INSERT INTO usuarioacessoobra (`numeroInventario`,`idUsuario`) VALUES ("1","5");
INSERT INTO usuarioacessoobra (`numeroInventario`,`idUsuario`) VALUES ("2","5");
INSERT INTO usuarioacessoobra (`numeroInventario`,`idUsuario`) VALUES ("6","5");



-- -----------------------------------------------------
-- Table `webMuseu`.`usuariofacebook`
-- -----------------------------------------------------

DROP TABLE IF EXISTS usuariofacebook;
CREATE TABLE `usuariofacebook` (
  `idUsuarioFacebook` varchar(50) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  PRIMARY KEY (`idUsuarioFacebook`),
  KEY `fk_UsuarioFacebook_Usuario_idx` (`idUsuario`),
  CONSTRAINT `fk_UsuarioFacebook_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `usuariofacebook`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`usuariogoogle`
-- -----------------------------------------------------

DROP TABLE IF EXISTS usuariogoogle;
CREATE TABLE `usuariogoogle` (
  `idUsuarioGoogle` varchar(50) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  PRIMARY KEY (`idUsuarioGoogle`),
  KEY `fk_UsuarioGoogle_Usuario_idx` (`idUsuario`),
  CONSTRAINT `fk_UsuarioGoogle_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `usuariogoogle`
--




