-- pjl SQL Dump
-- Server version:5.7.14
-- Generated: 2017-08-19 03:22:31
-- Current PHP version: 7.0.10
-- localhost: localhost
-- Database:webMuseu
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema webMuseu
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `webMuseu` DEFAULT CHARACTER SET utf8 ;
USE `webMuseu` ;

-- -----------------------------------------------------
-- Table `webMuseu`.`arquivo`
-- -----------------------------------------------------

DROP TABLE IF EXISTS arquivo;
CREATE TABLE `arquivo` (
  `idArquivo` int(11) NOT NULL AUTO_INCREMENT,
  `caminho` varchar(200) NOT NULL,
  `tipo` enum('IMAGEM','MODELO3D','TEXTURA') NOT NULL,
  PRIMARY KEY (`idArquivo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `arquivo`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`arquivoobra`
-- -----------------------------------------------------

DROP TABLE IF EXISTS arquivoobra;
CREATE TABLE `arquivoobra` (
  `idObra` int(11) NOT NULL,
  `idArquivo` int(11) NOT NULL,
  PRIMARY KEY (`idObra`,`idArquivo`),
  KEY `fk_idArquivo_idx` (`idArquivo`),
  CONSTRAINT `fk_ArquivoObra_Arquivo` FOREIGN KEY (`idArquivo`) REFERENCES `arquivo` (`idArquivo`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ArquivoObra_Obra` FOREIGN KEY (`idObra`) REFERENCES `obra` (`numeroInventario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `arquivoobra`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`backup`
-- -----------------------------------------------------

DROP TABLE IF EXISTS backup;
CREATE TABLE `backup` (
  `idBackup` int(11) NOT NULL AUTO_INCREMENT,
  `caminho` varchar(200) NOT NULL,
  `dataHora` datetime NOT NULL,
  PRIMARY KEY (`idBackup`)
) ENGINE=InnoDB AUTO_INCREMENT=232 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `backup`
--

INSERT INTO backup (`idBackup`,`caminho`,`dataHora`) VALUES ("227","backups/backup_2017-08-1518-08-21.zip","2017-08-15 18:08:21");
INSERT INTO backup (`idBackup`,`caminho`,`dataHora`) VALUES ("228","backups/backup_2017-08-1518-09-17.zip","2017-08-15 18:09:17");
INSERT INTO backup (`idBackup`,`caminho`,`dataHora`) VALUES ("229","backups/backup_2017-08-1915-13-39.zip","2017-08-19 15:13:39");
INSERT INTO backup (`idBackup`,`caminho`,`dataHora`) VALUES ("230","backups/backup_2017-08-1915-15-38.zip","2017-08-19 15:15:38");
INSERT INTO backup (`idBackup`,`caminho`,`dataHora`) VALUES ("231","backups/backup_2017-08-1915-18-17.zip","2017-08-19 15:18:17");



-- -----------------------------------------------------
-- Table `webMuseu`.`classificacao`
-- -----------------------------------------------------

DROP TABLE IF EXISTS classificacao;
CREATE TABLE `classificacao` (
  `idClassificacao` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  PRIMARY KEY (`idClassificacao`),
  UNIQUE KEY `nome_UNIQUE` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `classificacao`
--

INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("42","aaaaaaaaaaaaaaaaaaaa");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("26","amet, dapibus");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("5","amet, risus.");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("18","arcu. Vestibulum");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("39","consequat purus.");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("16","Donec egestas.");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("34","Donec est.");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("15","Donec tempus,");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("23","erat. Sed");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("41","fdsfsdfdsfdf");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("29","fermentum convallis");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("48","Fotografia");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("44","hghgh");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("43","iiiiiiiiiiiiiii");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("33","imperdiet non,");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("20","In mi");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("12","ipsum. Suspendisse");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("9","laoreet, libero");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("13","libero. Morbi");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("40","litora torquent");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("8","magna. Nam");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("7","magnis dis");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("10","malesuada fames");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("28","mi tempor");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("21","montes, nascetur");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("31","nisl. Nulla");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("17","nulla ante,");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("36","Nullam enim.");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("11","orci tincidunt");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("24","penatibus et");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("6","Phasellus libero");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("19","Phasellus ornare.");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("37","posuere cubilia");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("25","primis in");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("35","pulvinar arcu");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("27","quis, pede.");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("22","rhoncus. Proin");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("45","rrrrrrr");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("32","Suspendisse commodo");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("1","ultrices iaculis");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("4","ultrices sit");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("47","uuuuuuuuuuuu");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("30","venenatis lacus.");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("3","Vestibulum accumsan");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("2","vitae, aliquet");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("14","viverra. Donec");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("38","vulputate ullamcorper");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("46","yyyyyy");



-- -----------------------------------------------------
-- Table `webMuseu`.`colecao`
-- -----------------------------------------------------

DROP TABLE IF EXISTS colecao;
CREATE TABLE `colecao` (
  `idColecao` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  PRIMARY KEY (`idColecao`),
  UNIQUE KEY `nome_UNIQUE` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `colecao`
--

INSERT INTO colecao (`idColecao`,`nome`) VALUES ("56","aaaaaaaaaa");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("3","Alexa");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("12","Alfreda");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("11","Alika");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("35","Amity");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("34","Aubrey");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("7","Ava");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("57","bbbbbbbbbbb");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("19","Blossom");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("30","Brenna");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("20","Brooke");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("58","ccccccccccc");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("38","Charissa");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("24","Daphne");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("59","ddddd");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("6","Deirdre");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("10","Diana");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("33","Eden");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("63","eeeeeeeeeeeeeeeeee");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("17","Evangeline");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("15","Eve");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("29","Fatima");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("62","fhhgf");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("65","ggggggggg");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("8","Giselle");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("5","Hedwig");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("39","Helen");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("64","hghgghh");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("27","Hillary");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("36","Isadora");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("18","Jaime");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("14","Karen");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("22","Karleigh");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("4","Kirestin");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("60","kkkkkkkkkkkkkkkk");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("9","Kyra");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("21","Lael");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("13","Maya");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("28","Melyssa");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("37","Mia");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("61","mortaaaaaaaaa");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("23","Orla");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("31","Quincy");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("26","Quynn");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("40","Shay");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("2","Suki");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("41","valmir");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("25","Vanna");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("32","Veda");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("1","Xena");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("16","Zephr");



-- -----------------------------------------------------
-- Table `webMuseu`.`fotografia`
-- -----------------------------------------------------

DROP TABLE IF EXISTS fotografia;
CREATE TABLE `fotografia` (
  `idFotografia` int(11) NOT NULL,
  `Fotografo` varchar(50) DEFAULT NULL,
  `data` date DEFAULT NULL,
  `autorFotografia` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`idFotografia`),
  CONSTRAINT `fk_Fotografia_Obra` FOREIGN KEY (`idFotografia`) REFERENCES `obra` (`numeroInventario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `fotografia`
--

INSERT INTO fotografia (`idFotografia`,`Fotografo`,`data`,`autorFotografia`) VALUES ("5","ddsffd","","");
INSERT INTO fotografia (`idFotografia`,`Fotografo`,`data`,`autorFotografia`) VALUES ("444","dasdsads","","");
INSERT INTO fotografia (`idFotografia`,`Fotografo`,`data`,`autorFotografia`) VALUES ("6656","sdaddsdsasd","","");
INSERT INTO fotografia (`idFotografia`,`Fotografo`,`data`,`autorFotografia`) VALUES ("8989","dsffdsfd","","");
INSERT INTO fotografia (`idFotografia`,`Fotografo`,`data`,`autorFotografia`) VALUES ("34224","dffdsfsdfd","","");
INSERT INTO fotografia (`idFotografia`,`Fotografo`,`data`,`autorFotografia`) VALUES ("99009","gfdfgf","","");
INSERT INTO fotografia (`idFotografia`,`Fotografo`,`data`,`autorFotografia`) VALUES ("323323","DDSDDSAADS","","");
INSERT INTO fotografia (`idFotografia`,`Fotografo`,`data`,`autorFotografia`) VALUES ("434332","","","fddsffdsfd");
INSERT INTO fotografia (`idFotografia`,`Fotografo`,`data`,`autorFotografia`) VALUES ("434436","FDFDFDSFDSFD","","");
INSERT INTO fotografia (`idFotografia`,`Fotografo`,`data`,`autorFotografia`) VALUES ("655665","dfssfdsfd","","");
INSERT INTO fotografia (`idFotografia`,`Fotografo`,`data`,`autorFotografia`) VALUES ("989359","kjnsfdkfsdnj","","");
INSERT INTO fotografia (`idFotografia`,`Fotografo`,`data`,`autorFotografia`) VALUES ("4493843","hghhgdhgg","","");
INSERT INTO fotografia (`idFotografia`,`Fotografo`,`data`,`autorFotografia`) VALUES ("9342000","sdfdgghfg","","");
INSERT INTO fotografia (`idFotografia`,`Fotografo`,`data`,`autorFotografia`) VALUES ("9839438","ddjhghgjh","","");



-- -----------------------------------------------------
-- Table `webMuseu`.`funcionario`
-- -----------------------------------------------------

DROP TABLE IF EXISTS funcionario;
CREATE TABLE `funcionario` (
  `matricula` int(11) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  `funcao` varchar(45) NOT NULL,
  `cadastroObra` tinyint(1) NOT NULL,
  `gerenciaObra` tinyint(1) NOT NULL,
  `remocaoObra` tinyint(1) NOT NULL,
  `cadastroNoticia` tinyint(1) NOT NULL,
  `gerenciaNoticia` tinyint(1) NOT NULL,
  `remocaoNoticia` tinyint(1) NOT NULL,
  `backup` tinyint(1) NOT NULL,
  PRIMARY KEY (`matricula`),
  UNIQUE KEY `idUsuario_UNIQUE` (`idUsuario`),
  KEY `fk_Funcionario_Usuario_idx` (`idUsuario`),
  CONSTRAINT `fk_Funcionario_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `funcionario`
--

INSERT INTO funcionario (`matricula`,`idUsuario`,`funcao`,`cadastroObra`,`gerenciaObra`,`remocaoObra`,`cadastroNoticia`,`gerenciaNoticia`,`remocaoNoticia`,`backup`) VALUES ("14211151","281","Something","1","0","0","0","0","0","0");
INSERT INTO funcionario (`matricula`,`idUsuario`,`funcao`,`cadastroObra`,`gerenciaObra`,`remocaoObra`,`cadastroNoticia`,`gerenciaNoticia`,`remocaoNoticia`,`backup`) VALUES ("15111215","270","Qualquer coisa","1","0","0","0","0","0","0");



-- -----------------------------------------------------
-- Table `webMuseu`.`logalteracoes`
-- -----------------------------------------------------

DROP TABLE IF EXISTS logalteracoes;
CREATE TABLE `logalteracoes` (
  `idLogAlteracoes` int(11) NOT NULL AUTO_INCREMENT,
  `matriculaFuncionario` int(11) NOT NULL,
  `idItemAlterado` int(11) NOT NULL,
  `tipoItemAlterado` enum('NOTICIA','OBRA','BACKUP','FUNCIONARIO') NOT NULL,
  `descricao` varchar(1000) NOT NULL,
  `dataHora` datetime NOT NULL,
  PRIMARY KEY (`idLogAlteracoes`),
  KEY `fk_LogAlteracoes_Funcionario_idx` (`matriculaFuncionario`),
  CONSTRAINT `fk_LogAlteracoes_Funcionario` FOREIGN KEY (`matriculaFuncionario`) REFERENCES `funcionario` (`matricula`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `logalteracoes`
--

INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("1","15111215","661","OBRA","Cadastrar pesquisa","2017-07-27 21:02:38");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("2","15111215","661","OBRA","Cadastrar pesquisa","2017-07-27 21:02:38");
INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("3","15111215","661","OBRA","Cadastrar pesquisa","2017-07-27 21:02:39");



-- -----------------------------------------------------
-- Table `webMuseu`.`noticia`
-- -----------------------------------------------------

DROP TABLE IF EXISTS noticia;
CREATE TABLE `noticia` (
  `idNoticia` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(50) NOT NULL,
  `subtitulo` varchar(100) DEFAULT NULL,
  `descricao` varchar(500) DEFAULT NULL,
  `caminhoImagem` varchar(200) DEFAULT NULL,
  `data` date NOT NULL,
  PRIMARY KEY (`idNoticia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `noticia`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`obra`
-- -----------------------------------------------------

DROP TABLE IF EXISTS obra;
CREATE TABLE `obra` (
  `numeroInventario` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `funcao` varchar(45) DEFAULT NULL,
  `origem` varchar(45) DEFAULT NULL,
  `procedencia` varchar(45) DEFAULT NULL,
  `descricao` varchar(3000) DEFAULT NULL,
  `idColecao` int(11) NOT NULL,
  `idClassificacao` int(11) NOT NULL,
  `altura` float DEFAULT NULL,
  `largura` float DEFAULT NULL,
  `diametro` float DEFAULT NULL,
  `peso` float DEFAULT NULL,
  `comprimento` float DEFAULT NULL,
  `materiaisContruidos` varchar(200) DEFAULT NULL,
  `tecnicasFabricacao` varchar(100) DEFAULT NULL,
  `autoria` varchar(45) DEFAULT NULL,
  `marcasInscricoes` varchar(200) DEFAULT NULL,
  `historicoObjeto` varchar(200) DEFAULT NULL,
  `modoAquisicao` varchar(45) DEFAULT NULL,
  `dataAquisicao` date DEFAULT NULL,
  `autor` varchar(45) DEFAULT NULL,
  `observacoes` varchar(100) DEFAULT NULL,
  `estadoConservacao` varchar(45) DEFAULT NULL,
  `caminhoImagem1` varchar(300) DEFAULT NULL,
  `caminhoImagem2` varchar(300) DEFAULT NULL,
  `caminhoImagem3` varchar(300) DEFAULT NULL,
  `caminhoImagem4` varchar(300) DEFAULT NULL,
  `caminhoImagem5` varchar(300) DEFAULT NULL,
  `caminhoModelo3D` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`numeroInventario`),
  KEY `idCategoria_idx` (`idClassificacao`),
  KEY `fk_idColecao_obra_idx` (`idColecao`),
  CONSTRAINT `fk_Obra_Classificacao` FOREIGN KEY (`idClassificacao`) REFERENCES `classificacao` (`idClassificacao`) ON UPDATE CASCADE,
  CONSTRAINT `fk_Obra_Colecao` FOREIGN KEY (`idColecao`) REFERENCES `colecao` (`idColecao`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `obra`
--

INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("5","sadffddf","asdffdfd","","","","","34","48","","","","","","","","","","","","","","","","","","","","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("112","sfgretrtr","etrtrtet","","","","","57","20","","","","","","","","","","","","","","","","","","","","","C:\wamp64\www\sertour/media/obras/modelo3d/0112");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("444","sdffffd","fdsdfsd","","","","","57","48","","","","","","","","","","","","","","","","","","","","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("656","sdfgssggfgf","gggdgf","","","","","19","20","","","","","","","","","","","","","","","","../media/obras/imagens/656/1.jpg","","","","","C:\wamp64\www\sertour/media/obras/modelo3d/656mm.obj");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("888","lkmlklm","kmmkmlm","","","","","7","12","","","","","","","","","","","","","","","","../media/obras/imagens/888/valmir.gif","","","","","../media/obras/modelo3d/888Heart.obj");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("990","kmdfskfkmlf","jkdsfdnj","","","","","56","42","","","","","","","","","","","","","","","","","","","","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("999","humm","2","","","","","56","42","","","","","","","","","","","","","","","","../media/obras/imagens/999/valmir.gif","","","","","../media/obras/modelo3d/999Heart.obj");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("1212","dfsfdsfdsfd","dfsdd","","","","","7","20","","","","","","","","","","","","","","","","","","","","","C:\wamp64\www\sertour/media/obras/modelo3d/1212");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("1524","sdfsfdsfsdf","fsdfdsfdsfds","","","","","19","15","","","","","","","","","","","","","","","","../media/obras/imagens/1524/B4dI5clCEAAo-p1.png","","","","","C:\wamp64\www\sertour/media/obras/modelo3d/1524mm.obj");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("3366","fgfdg","dgdgd","","","","","7","20","","","","","","","","","","","","","","","","","","","","","C:\wamp64\www\sertour/media/obras/modelo3d/3366");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("4455","fdsfdsdff","dfdsfdsf","","","","","57","43","","","","","","","","","","","","","","","","","","","","","C:\wamp64\www\sertour/media/obras/modelo3d/4455");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("6656","dfsffd","fsdffdfd","","","","","35","48","","","","","","","","","","","","","","","","","","","","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("6764","fdsfdfsd","fdsfdsfds","","","","","35","12","","","","","","","","","","","","","","","","","","","","","C:\wamp64\www\sertour/media/obras/modelo3d/6764");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("7070","cxvcxcvc","vcvcvcx","","","","","11","20","","","","","","","","","","","","","","","","","","","","","C:\wamp64\www\sertour/media/obras/modelo3d/7070");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("8777","nkjsnkdn","jkkjsdkj","","","","","19","43","","","","","","","","","","","","","","","","../media/obras/imagens/8777/valmir.gif","","","","","../media/obras/imagens/8777Heart.obj");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("8989","PORRA","KDSMKMDSD","","","","","56","48","","","","","","","","","","","","","","","","","","","","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("9128","AAAAAAAAAAAAAAAA","AAAAAAAAA","","","","","56","42","","","","","","","","","","","","","","","","../media/obras/imagens/9128/1.jpg","","","","","C:\wamp64\www\sertour/media/obras/modelo3d/9128mm.obj");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("9987","fsdfffdsd","fdsdsffdd","","","","","34","29","","","","","","","","","","","","","","","","../media/obras/imagens/9987/vapor.jpg","","","","","mod.obj");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("10101","fdsfdsdffds","fdfsdfd","","","","","35","20","","","","","","","","","","","","","","","","","","","","","C:\wamp64\www\sertour/media/obras/modelo3d/010101");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("11111","dfsfsdsfdf","fsdfdsfddf","","","","","38","34","","","","","","","","","","","","","","","","../media/obras/imagens/11111/B4dI5clCEAAo-p1.png","","","","","mm.obj");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("15854","flsdlfkddmf","klmkfd","","","","","34","12","","","","","","","","","","","","","","","","../media/obras/imagens/15854/valmir.gif","","","","","../media/obras/imagens/15854Heart.obj");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("22222","sdffdfdfd","fsdsdfsf","","","","","57","34","","","","","","","","","","","","","","","","..media/obras/imagens/22222/B4dI5clCEAAo-p1.png","","","","","mm.obj");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("34224","dfsfdfd","fssffds","","","","","57","48","","","","","","","","","","","","","","","","","","","","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("44554","fdfssdffd","fsdfdsfd","","","","","30","13","","","","","","","","","","","","","","","","","","","","","C:\wamp64\www\sertour/media/obras/modelo3d/44554");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("54544","fdfdsfdssfd","fsfdsfdsfd","","","","","20","23","","","","","","","","","","","","","","","","","","","","","C:\wamp64\www\sertour/media/obras/modelo3d/54544");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("56788","fgdgg","gfgdg","","","","","11","20","","","","","","","","","","","","","","","","","","","","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("65676","jhjjhjg","jgjgj","","","","","35","20","","","","","","","","","","","","","","","","../media/obras/imagens/65676/valmir.gif","","","","","../media/obras/imagens/65676Heart.obj");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("65757","dfghghh","hfhfghf","","","","","34","16","","","","","","","","","","","","","","","","../media/obras/imagens/65757/valmir.gif","","","","","../media/obras/imagens/65757mod.obj");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("66666","sdsfdfsdf","sdffdffd","","","","","7","12","","","","","","","","","","","","","","","","","","","","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("83489","klfkmkdfs","dfnjddnfdfnj","","","","","56","42","","","","","","","","","","","","","","","","","","","","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("83984","workworkwork","workworkwork","","","","","11","33","","","","","","","","","","","","","","","","","","","","","../media/obras/modelo3d/83984");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("87777","lkfdsmklfmsdf","lkamkldmfd","","","","","56","42","","","","","","","","","","","","","","","","","","","","","C:\wamp64\www\sertour/media/obras/modelo3d/87777");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("99009","fsdffds","fsdffd","","","","","56","48","","","","","","","","","","","","","","","","","","","","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("111123","oo","oo","","","","","11","12","","","","","","","","","","","","","","","","C:\wamp64\www\sertour/media/obras/imagens/111123/1.jpg","","","","","C:\wamp64\www\sertour/media/obras/modelo3d/111123mm.obj");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("232323","sdfdfsdfsdf","dssfdd","","","","","34","18","","","","","","","","","","","","","","","","C:\wamp64\www\sertour/media/obras/imagens/232323/37362.jpg","","","","","C:\wamp64\www\sertour/media/obras/modelo3d/232323mm.obj");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("323323","DFSDFDSDS","DFSDSFDSFD","","","","","7","48","","","","","","","","","","","","","","","","","","","","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("342342","sdffsffdss","fdfdsfdf","","","","","19","12","","","","","","","","","","","","","","","","","","","","","C:\wamp64\www\sertour/media/obras/modelo3d/342342");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("434332","dsasd","dsasddsds","","","","","35","48","","","","","","","","","","","","","","","","","","","","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("434436","FDFSDDFFD","FFDFSD","","","","","7","48","","","","","","","","","","","","","","","","","","","","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("454545","sdfdffdsfds","fdsfdsfd","","","","","34","43","","","","","","","","","","","","","","","","","","","","","C:\wamp64\www\sertour/media/obras/modelo3d/454545");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("474288","sgdfffkm","dsajdjsn","","","","","56","42","","","","","","","","","","","","","","","","","","","","","C:\wamp64\www\sertour/media/obras/modelo3d/474288");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("655665","sdffsfd","fdsdffd","","","","","35","48","","","","","","","","","","","","","","","","","","","","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("727727","workworkwork","workworkwork","","","","","56","42","","","","","","","","","","","","","","","","../media/obras/imagens/727727/valmir.gif","../media/obras/imagens/727727/valmir.gif","../media/obras/imagens/727727/valmir.gif","","","../media/obras/modelo3D/727727/mod.obj");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("876542","aaaaaaaaaa","aaaaaaaaaa","","","","","57","20","","","","","","","","","","","","","","","","","","","","","C:\wamp64\www\sertour/media/obras/modelo3d/876542");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("876543","AAAAAAAAAAAA","AAAAAAAAAAAAA","","","","","10","12","","","","","","","","","","","","","","","","../media/obras/imagens/876543/valmir.gif","","","","","../media/obras/modelo3d/876543Heart.obj");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("989359","fdsfsfd","fddfssfd","","","","","56","48","","","","","","","","","","","","","","","","","","","","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("989899","gdggdgdfg","gfggfd","","","","","34","12","","","","","","","","","","","","","","","","","","","","","C:\wamp64\www\sertour/media/obras/modelo3d/989899");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("3098092","Pabllo","Pabllo","Pabllo","Pabllo","Pabllo","","3","26","","","","","","","","","","","","","","","","../media/obras/imagens/727727/valmir.gif","../media/obras/imagens/727727/valmir.gif","../media/obras/imagens/727727/valmir.gif","../media/obras/imagens/727727/valmir.gif","../media/obras/imagens/727727/valmir.gif","C:\wamp64\www\sertour/media/obras/modelo3d/3098092.");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("4455454","ssfdsfd","fsdfsdfs","","","","","35","33","","","","","","","","","","","","","","","","","","","","","C:\wamp64\www\sertour/media/obras/modelo3d/4455454");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("4493843",",mdfdsmfnfsn","kjafdfnnfds","","","","","24","48","","","","","","","","","","","","","","","","","","","","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("5463423","dfdfdgsg","dfsdf","","","","","57","43","","","","","","","","","","","","","","","","../media/obras/imagens/5463423/1.jpg","","","","","../media/obras/imagens/5463423Heart.obj");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("6664564","gfdggf","gfgfd","","","","","3","48","","","","","","","","","","","","","","","","","","","","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("9342000","dssfgfgf","dfgf","","","","","7","48","","","","","","","","","","","","","","","","","","","","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("9489823","objetooo","objetooo","","","","","35","43","","","","","","","","","","","","","","","","C:\wamp64\www\sertour/media/obras/imagens/9489823/1.jpg","","","","","C:\wamp64\www\sertour/media/obras/modelo3d/9489823mm.obj");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("9839438","onakmdllk","dkdskffmkdl","","","","","3","48","","","","","","","","","","","","","","","","","","","","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("67767676","dsddfsfd","fd","","","","","34","33","","","","","","","","","","","","","","","","","","","","","C:\wamp64\www\sertour/media/obras/modelo3d/67767676");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("75717978","w0","w0","","","","","12","42","","","","","","","","","","","","","","","","C:\wamp64\www\sertour/media/obras/imagens/75717978/valmir.gif","","","","","C:\wamp64\www\sertour/media/obras/modelo3d/75717978mm.obj");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("87676467","cbfghhf","jhgjhhj","","","","","7","34","","","","","","","","","","","","","","","","C:\wamp64\www\sertour/media/obras/imagens/87676467/.","C:\wamp64\www\sertour/media/obras/imagens/87676467/..","C:\wamp64\www\sertour/media/obras/imagens/87676467/valmir.gif","","","C:\wamp64\www\sertour/media/obras/modelo3d/87676467.");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("92984948","corposensual","corposensual","","","","","56","42","","","","","","","","","","","","","","","","C:\wamp64\www\sertour/media/obras/imagens/92984948/.","C:\wamp64\www\sertour/media/obras/imagens/92984948/..","C:\wamp64\www\sertour/media/obras/imagens/92984948/1.jpg","","","C:\wamp64\www\sertour/media/obras/modelo3d/92984948.");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("983475682","OBJ","OBJ","","","","","57","43","","","","","","","","","","","","","","","","C:\wamp64\www\sertour/media/obras/imagens/983475682/valmir.gif","","","","","C:\wamp64\www\sertour/media/obras/modelo3d/983475682mod.obj");



-- -----------------------------------------------------
-- Table `webMuseu`.`opcao`
-- -----------------------------------------------------

DROP TABLE IF EXISTS opcao;
CREATE TABLE `opcao` (
  `idOpcao` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(45) NOT NULL,
  PRIMARY KEY (`idOpcao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `opcao`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`pergunta`
-- -----------------------------------------------------

DROP TABLE IF EXISTS pergunta;
CREATE TABLE `pergunta` (
  `idPergunta` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(45) NOT NULL,
  `opcional` tinyint(1) NOT NULL,
  `tipo` enum('ABERTA','UNICA ESCOLHA','MULTIPLA ESCOLHA') NOT NULL,
  PRIMARY KEY (`idPergunta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `pergunta`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`perguntaopcao`
-- -----------------------------------------------------

DROP TABLE IF EXISTS perguntaopcao;
CREATE TABLE `perguntaopcao` (
  `idPergunta` int(11) NOT NULL,
  `idOpcao` int(11) NOT NULL,
  PRIMARY KEY (`idPergunta`,`idOpcao`),
  KEY `fk_PerguntaOpcao_Opcao_idx` (`idOpcao`),
  CONSTRAINT `fk_PerguntaOpcao_Opcao` FOREIGN KEY (`idOpcao`) REFERENCES `opcao` (`idOpcao`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_PerguntaOpcao_Pergunta` FOREIGN KEY (`idPergunta`) REFERENCES `pergunta` (`idPergunta`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `perguntaopcao`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`perguntapesquisa`
-- -----------------------------------------------------

DROP TABLE IF EXISTS perguntapesquisa;
CREATE TABLE `perguntapesquisa` (
  `idPergunta` int(11) NOT NULL,
  `idPesquisa` int(11) NOT NULL,
  PRIMARY KEY (`idPergunta`,`idPesquisa`),
  KEY `fk_PerguntaPesquisa_Pesquisa_idx` (`idPesquisa`),
  CONSTRAINT `fk_PerguntaPesquisa_Pergunta` FOREIGN KEY (`idPergunta`) REFERENCES `pergunta` (`idPergunta`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_PerguntaPesquisa_Pesquisa` FOREIGN KEY (`idPesquisa`) REFERENCES `pesquisa` (`idPesquisa`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `perguntapesquisa`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`pesquisa`
-- -----------------------------------------------------

DROP TABLE IF EXISTS pesquisa;
CREATE TABLE `pesquisa` (
  `idPesquisa` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(45) NOT NULL,
  `descricao` varchar(200) DEFAULT NULL,
  `estaAtiva` tinyint(1) NOT NULL,
  PRIMARY KEY (`idPesquisa`),
  UNIQUE KEY `titulo_UNIQUE` (`titulo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `pesquisa`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`respostaaberta`
-- -----------------------------------------------------

DROP TABLE IF EXISTS respostaaberta;
CREATE TABLE `respostaaberta` (
  `idUsuario` int(11) NOT NULL,
  `idPesquisa` int(11) NOT NULL,
  `idPergunta` int(11) NOT NULL,
  `descricao` text NOT NULL,
  PRIMARY KEY (`idUsuario`,`idPesquisa`,`idPergunta`),
  KEY `fk_RespostaAberta_Pergunta_idx` (`idPergunta`),
  KEY `fk_RespostaAberta_Pesquisa_idx` (`idPesquisa`),
  CONSTRAINT `fk_RespostaAberta_Pergunta` FOREIGN KEY (`idPergunta`) REFERENCES `pergunta` (`idPergunta`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_RespostaAberta_Pesquisa` FOREIGN KEY (`idPesquisa`) REFERENCES `pesquisa` (`idPesquisa`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_RespostaAberta_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `respostaaberta`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`respostafechada`
-- -----------------------------------------------------

DROP TABLE IF EXISTS respostafechada;
CREATE TABLE `respostafechada` (
  `idUsuario` int(11) NOT NULL,
  `idPesquisa` int(11) NOT NULL,
  `idPergunta` int(11) NOT NULL,
  `idOpcao` int(11) NOT NULL,
  PRIMARY KEY (`idUsuario`,`idPesquisa`,`idPergunta`,`idOpcao`),
  KEY `fk_RespostaSelecionada_Opcao_idx` (`idOpcao`),
  KEY `fk_RespostaFechada_Pergunta_idx` (`idPergunta`),
  KEY `fk_RespostaFechada_Pesquisa_idx` (`idPesquisa`),
  CONSTRAINT `fk_RespostaFechada_Opcao` FOREIGN KEY (`idOpcao`) REFERENCES `opcao` (`idOpcao`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_RespostaFechada_Pergunta` FOREIGN KEY (`idPergunta`) REFERENCES `pergunta` (`idPergunta`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_RespostaFechada_Pesquisa` FOREIGN KEY (`idPesquisa`) REFERENCES `pesquisa` (`idPesquisa`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_RespostaFechada_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `respostafechada`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`tag`
-- -----------------------------------------------------

DROP TABLE IF EXISTS tag;
CREATE TABLE `tag` (
  `idTag` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(45) NOT NULL,
  PRIMARY KEY (`idTag`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `tag`
--

INSERT INTO tag (`idTag`,`descricao`) VALUES ("1","tag teste");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("2","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("3","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("4","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("5","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("6","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("7","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("8","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("9","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("10","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("11","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("12","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("13","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("14","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("15","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("16","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("17","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("18","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("19","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("20","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("21","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("22","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("23","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("24","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("25","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("26","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("27","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("28","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("29","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("30","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("31","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("32","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("33","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("34","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("35","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("36","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("37","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("38","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("39","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("40","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("41","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("42","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("43","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("44","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("45","valmir");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("46","vini");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("47","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("48","fode");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("49","caralho");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("50","porra");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("51","merda");



-- -----------------------------------------------------
-- Table `webMuseu`.`tagobra`
-- -----------------------------------------------------

DROP TABLE IF EXISTS tagobra;
CREATE TABLE `tagobra` (
  `idTag` int(11) NOT NULL,
  `idObra` int(11) NOT NULL,
  PRIMARY KEY (`idTag`,`idObra`),
  KEY `fk_idObra_idx` (`idObra`),
  CONSTRAINT `fk_TagObra_Obra` FOREIGN KEY (`idObra`) REFERENCES `obra` (`numeroInventario`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_TagObra_Tag` FOREIGN KEY (`idTag`) REFERENCES `tag` (`idTag`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `tagobra`
--

INSERT INTO tagobra (`idTag`,`idObra`) VALUES ("50","990");
INSERT INTO tagobra (`idTag`,`idObra`) VALUES ("51","990");
INSERT INTO tagobra (`idTag`,`idObra`) VALUES ("47","83489");
INSERT INTO tagobra (`idTag`,`idObra`) VALUES ("48","83489");
INSERT INTO tagobra (`idTag`,`idObra`) VALUES ("49","83489");



-- -----------------------------------------------------
-- Table `webMuseu`.`usuario`
-- -----------------------------------------------------

DROP TABLE IF EXISTS usuario;
CREATE TABLE `usuario` (
  `idUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(20) NOT NULL,
  `sobrenome` varchar(45) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `senha` varchar(50) DEFAULT NULL,
  `cadastroConfirmado` tinyint(1) NOT NULL,
  `tipoUsuario` enum('USUARIO','FUNCIONARIO','ADMINISTRADOR') DEFAULT NULL,
  PRIMARY KEY (`idUsuario`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=323 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `usuario`
--

INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("269","Nome","Sobrenome","email@email.com","ff64a1c43498d955147518733ac88c7c","1","ADMINISTRADOR");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("270","Diego","Loureno","diegossl94@gmail.com","25d55ad283aa400af464c76d713c07ad","1","FUNCIONARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("271","Fulano Face","De Face","v@gmail.com","","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("272","Fulano Google","De Google","g@gmail.com","","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("274","Fulano","De Tal","t@gmail.com","1bbd886460827015e5d605ed44252251","0","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("281","Aloisio","Junior","kleyner2@hotmail.com","25d55ad283aa400af464c76d713c07ad","1","FUNCIONARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("300","Ionara","de Almeida","","","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("315","Valmir","Vinicius","naughtynaughtyweliketoparty@live.com","52ae1afec952b779782a47ce2c07cdc5","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("316","Valmir","Vinicius","dfskjdfjkf@gmail.com","a88d6dbaf322a72c2ecb39fec6066d89","0","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("318","fpfmsdofsmfds'","dfklfdfsdk","girlsrollup@gmail.com","52ae1afec952b779782a47ce2c07cdc5","0","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("319","Carol","Lisboa","batedbreath@outlook.com","","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("320","Brian","Levitt","babywhenwetouchinthedark@gmail.com","","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("321","AAAAAA","kmsdmfsk","niallszn@outlook.com","52ae1afec952b779782a47ce2c07cdc5","0","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("322","Valmir","Vinicius","vvalmeida96@gmail.com","52ae1afec952b779782a47ce2c07cdc5","1","USUARIO");



-- -----------------------------------------------------
-- Table `webMuseu`.`usuarioacessoobra`
-- -----------------------------------------------------

DROP TABLE IF EXISTS usuarioacessoobra;
CREATE TABLE `usuarioacessoobra` (
  `numeroInventario` int(11) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  PRIMARY KEY (`idUsuario`,`numeroInventario`),
  KEY `fk_UsuarioAcesso_Usuario_idx` (`idUsuario`),
  KEY `fk_UsuarioAcesso_AcessoObra_idx` (`numeroInventario`),
  CONSTRAINT `fk_UsuarioAcesso_AcessoObra` FOREIGN KEY (`numeroInventario`) REFERENCES `obra` (`numeroInventario`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_UsuarioAcesso_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `usuarioacessoobra`
--

INSERT INTO usuarioacessoobra (`numeroInventario`,`idUsuario`) VALUES ("727727","319");



-- -----------------------------------------------------
-- Table `webMuseu`.`usuariofacebook`
-- -----------------------------------------------------

DROP TABLE IF EXISTS usuariofacebook;
CREATE TABLE `usuariofacebook` (
  `idUsuarioFacebook` varchar(50) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  PRIMARY KEY (`idUsuarioFacebook`),
  KEY `fk_UsuarioFacebook_Usuario_idx` (`idUsuario`),
  CONSTRAINT `fk_UsuarioFacebook_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `usuariofacebook`
--

INSERT INTO usuariofacebook (`idUsuarioFacebook`,`idUsuario`) VALUES ("8181818181","271");
INSERT INTO usuariofacebook (`idUsuarioFacebook`,`idUsuario`) VALUES ("1742030152480823","300");
INSERT INTO usuariofacebook (`idUsuarioFacebook`,`idUsuario`) VALUES ("312585129183917","319");



-- -----------------------------------------------------
-- Table `webMuseu`.`usuariogoogle`
-- -----------------------------------------------------

DROP TABLE IF EXISTS usuariogoogle;
CREATE TABLE `usuariogoogle` (
  `idUsuarioGoogle` varchar(50) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  PRIMARY KEY (`idUsuarioGoogle`),
  KEY `fk_UsuarioGoogle_Usuario_idx` (`idUsuario`),
  CONSTRAINT `fk_UsuarioGoogle_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `usuariogoogle`
--

INSERT INTO usuariogoogle (`idUsuarioGoogle`,`idUsuario`) VALUES ("88238328","272");
INSERT INTO usuariogoogle (`idUsuarioGoogle`,`idUsuario`) VALUES ("114069096823522033440","320");



-- -----------------------------------------------------
-- Table `webMuseu`.`usuariorespostapesquisa`
-- -----------------------------------------------------

DROP TABLE IF EXISTS usuariorespostapesquisa;
CREATE TABLE `usuariorespostapesquisa` (
  `idUsuario` int(11) NOT NULL,
  `idPesquisa` int(11) NOT NULL,
  PRIMARY KEY (`idUsuario`,`idPesquisa`),
  KEY `fk_UsuarioRespostaPesquisa_Pesquisa_idx` (`idPesquisa`),
  CONSTRAINT `fk_UsuarioRespostaPesquisa_Pesquisa` FOREIGN KEY (`idPesquisa`) REFERENCES `pesquisa` (`idPesquisa`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_UsuarioRespostaPesquisa_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `usuariorespostapesquisa`
--




