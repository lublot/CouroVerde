-- pjl SQL Dump
-- Server version:5.7.14
-- Generated: 2017-08-22 04:39:06
-- Current PHP version: 7.0.10
-- localhost: localhost
-- Database:webMuseu
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema webMuseu
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `webMuseu` DEFAULT CHARACTER SET utf8 ;
USE `webMuseu` ;

-- -----------------------------------------------------
-- Table `webMuseu`.`arquivo`
-- -----------------------------------------------------

DROP TABLE IF EXISTS arquivo;
CREATE TABLE `arquivo` (
  `idArquivo` int(11) NOT NULL AUTO_INCREMENT,
  `caminho` varchar(200) NOT NULL,
  `tipo` enum('IMAGEM','MODELO3D','TEXTURA') NOT NULL,
  PRIMARY KEY (`idArquivo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `arquivo`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`arquivoobra`
-- -----------------------------------------------------

DROP TABLE IF EXISTS arquivoobra;
CREATE TABLE `arquivoobra` (
  `idObra` int(11) NOT NULL,
  `idArquivo` int(11) NOT NULL,
  PRIMARY KEY (`idObra`,`idArquivo`),
  KEY `fk_idArquivo_idx` (`idArquivo`),
  CONSTRAINT `fk_ArquivoObra_Arquivo` FOREIGN KEY (`idArquivo`) REFERENCES `arquivo` (`idArquivo`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ArquivoObra_Obra` FOREIGN KEY (`idObra`) REFERENCES `obra` (`numeroInventario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `arquivoobra`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`backup`
-- -----------------------------------------------------

DROP TABLE IF EXISTS backup;
CREATE TABLE `backup` (
  `idBackup` int(11) NOT NULL AUTO_INCREMENT,
  `caminho` varchar(200) NOT NULL,
  `dataHora` datetime NOT NULL,
  PRIMARY KEY (`idBackup`)
) ENGINE=InnoDB AUTO_INCREMENT=296 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `backup`
--

INSERT INTO backup (`idBackup`,`caminho`,`dataHora`) VALUES ("291","backups/backup_2017-08-2216-31-52.zip","2017-08-22 16:31:52");
INSERT INTO backup (`idBackup`,`caminho`,`dataHora`) VALUES ("292","backups/backup_2017-08-2216-32-41.zip","2017-08-22 16:32:41");
INSERT INTO backup (`idBackup`,`caminho`,`dataHora`) VALUES ("293","backups/backup_2017-08-2216-33-57.zip","2017-08-22 16:33:57");
INSERT INTO backup (`idBackup`,`caminho`,`dataHora`) VALUES ("294","backups/backup_2017-08-2216-34-39.zip","2017-08-22 16:34:39");
INSERT INTO backup (`idBackup`,`caminho`,`dataHora`) VALUES ("295","backups/backup_2017-08-2216-38-59.zip","2017-08-22 16:38:59");



-- -----------------------------------------------------
-- Table `webMuseu`.`classificacao`
-- -----------------------------------------------------

DROP TABLE IF EXISTS classificacao;
CREATE TABLE `classificacao` (
  `idClassificacao` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  PRIMARY KEY (`idClassificacao`),
  UNIQUE KEY `nome_UNIQUE` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `classificacao`
--

INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("3","Objetos");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("49","Objetos de Casa");
INSERT INTO classificacao (`idClassificacao`,`nome`) VALUES ("6","Objetos Pessoais");



-- -----------------------------------------------------
-- Table `webMuseu`.`colecao`
-- -----------------------------------------------------

DROP TABLE IF EXISTS colecao;
CREATE TABLE `colecao` (
  `idColecao` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  PRIMARY KEY (`idColecao`),
  UNIQUE KEY `nome_UNIQUE` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `colecao`
--

INSERT INTO colecao (`idColecao`,`nome`) VALUES ("3","Caricaturas");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("6","Chapus");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("5","Ferros");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("66","Luminrias");
INSERT INTO colecao (`idColecao`,`nome`) VALUES ("1","Pote");



-- -----------------------------------------------------
-- Table `webMuseu`.`fotografia`
-- -----------------------------------------------------

DROP TABLE IF EXISTS fotografia;
CREATE TABLE `fotografia` (
  `idFotografia` int(11) NOT NULL,
  `Fotografo` varchar(50) DEFAULT NULL,
  `data` date DEFAULT NULL,
  `autorFotografia` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`idFotografia`),
  CONSTRAINT `fk_Fotografia_Obra` FOREIGN KEY (`idFotografia`) REFERENCES `obra` (`numeroInventario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `fotografia`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`funcionario`
-- -----------------------------------------------------

DROP TABLE IF EXISTS funcionario;
CREATE TABLE `funcionario` (
  `matricula` int(11) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  `funcao` varchar(45) NOT NULL,
  `cadastroObra` tinyint(1) NOT NULL,
  `gerenciaObra` tinyint(1) NOT NULL,
  `remocaoObra` tinyint(1) NOT NULL,
  `cadastroNoticia` tinyint(1) NOT NULL,
  `gerenciaNoticia` tinyint(1) NOT NULL,
  `remocaoNoticia` tinyint(1) NOT NULL,
  `backup` tinyint(1) NOT NULL,
  PRIMARY KEY (`matricula`),
  UNIQUE KEY `idUsuario_UNIQUE` (`idUsuario`),
  KEY `fk_Funcionario_Usuario_idx` (`idUsuario`),
  CONSTRAINT `fk_Funcionario_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `funcionario`
--

INSERT INTO funcionario (`matricula`,`idUsuario`,`funcao`,`cadastroObra`,`gerenciaObra`,`remocaoObra`,`cadastroNoticia`,`gerenciaNoticia`,`remocaoNoticia`,`backup`) VALUES ("112233","1","Dona","1","1","1","1","1","1","1");
INSERT INTO funcionario (`matricula`,`idUsuario`,`funcao`,`cadastroObra`,`gerenciaObra`,`remocaoObra`,`cadastroNoticia`,`gerenciaNoticia`,`remocaoNoticia`,`backup`) VALUES ("445566","3","Funcionrio","1","1","1","0","0","0","1");



-- -----------------------------------------------------
-- Table `webMuseu`.`logalteracoes`
-- -----------------------------------------------------

DROP TABLE IF EXISTS logalteracoes;
CREATE TABLE `logalteracoes` (
  `idLogAlteracoes` int(11) NOT NULL AUTO_INCREMENT,
  `matriculaFuncionario` int(11) NOT NULL,
  `idItemAlterado` int(11) NOT NULL,
  `tipoItemAlterado` enum('NOTICIA','OBRA','BACKUP','FUNCIONARIO') NOT NULL,
  `descricao` varchar(1000) NOT NULL,
  `dataHora` datetime NOT NULL,
  PRIMARY KEY (`idLogAlteracoes`),
  KEY `fk_LogAlteracoes_Funcionario_idx` (`matriculaFuncionario`),
  CONSTRAINT `fk_LogAlteracoes_Funcionario` FOREIGN KEY (`matriculaFuncionario`) REFERENCES `funcionario` (`matricula`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `logalteracoes`
--

INSERT INTO logalteracoes (`idLogAlteracoes`,`matriculaFuncionario`,`idItemAlterado`,`tipoItemAlterado`,`descricao`,`dataHora`) VALUES ("80","445566","295","BACKUP","Um backup foi criado","2017-08-22 16:39:00");



-- -----------------------------------------------------
-- Table `webMuseu`.`noticia`
-- -----------------------------------------------------

DROP TABLE IF EXISTS noticia;
CREATE TABLE `noticia` (
  `idNoticia` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(50) NOT NULL,
  `subtitulo` varchar(100) DEFAULT NULL,
  `descricao` varchar(500) DEFAULT NULL,
  `caminhoImagem` varchar(200) DEFAULT NULL,
  `data` date NOT NULL,
  PRIMARY KEY (`idNoticia`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `noticia`
--

INSERT INTO noticia (`idNoticia`,`titulo`,`subtitulo`,`descricao`,`caminhoImagem`,`data`) VALUES ("12","Inaugurao Web Museu Casa do Serto","","O web museu casa do serto foi inaugurado no dia 23/08/2017, desenvolvido pela MITHOLOGIC Software. O nome escolhido foi SERTOUR.","media/noticias/imagens/20170821172133museo_casa_certao_1.jpg","2017-08-22");
INSERT INTO noticia (`idNoticia`,`titulo`,`subtitulo`,`descricao`,`caminhoImagem`,`data`) VALUES ("13","Nova coleo no Museu Casa do Serto","","O web museu casa do serto inaugurou uma nova coleo no dia 22/08/2017, nessa nova coleo esto expostos diversos tipos de mquinas.","media/noticias/imagens/20170821172456museo_casa_certao_2.jpg","2017-08-22");



-- -----------------------------------------------------
-- Table `webMuseu`.`obra`
-- -----------------------------------------------------

DROP TABLE IF EXISTS obra;
CREATE TABLE `obra` (
  `numeroInventario` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `funcao` varchar(45) DEFAULT NULL,
  `origem` varchar(45) DEFAULT NULL,
  `procedencia` varchar(45) DEFAULT NULL,
  `descricao` varchar(3000) DEFAULT NULL,
  `idColecao` int(11) NOT NULL,
  `idClassificacao` int(11) NOT NULL,
  `altura` float DEFAULT NULL,
  `largura` float DEFAULT NULL,
  `diametro` float DEFAULT NULL,
  `peso` float DEFAULT NULL,
  `comprimento` float DEFAULT NULL,
  `materiaisContruidos` varchar(200) DEFAULT NULL,
  `tecnicasFabricacao` varchar(100) DEFAULT NULL,
  `autoria` varchar(45) DEFAULT NULL,
  `marcasInscricoes` varchar(200) DEFAULT NULL,
  `historicoObjeto` varchar(200) DEFAULT NULL,
  `modoAquisicao` varchar(45) DEFAULT NULL,
  `dataAquisicao` date DEFAULT NULL,
  `autor` varchar(45) DEFAULT NULL,
  `observacoes` varchar(100) DEFAULT NULL,
  `estadoConservacao` varchar(45) DEFAULT NULL,
  `caminhoImagem1` varchar(300) DEFAULT NULL,
  `caminhoImagem2` varchar(300) DEFAULT NULL,
  `caminhoImagem3` varchar(300) DEFAULT NULL,
  `caminhoImagem4` varchar(300) DEFAULT NULL,
  `caminhoImagem5` varchar(300) DEFAULT NULL,
  `caminhoModelo3D` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`numeroInventario`),
  KEY `idCategoria_idx` (`idClassificacao`),
  KEY `fk_idColecao_obra_idx` (`idColecao`),
  CONSTRAINT `fk_Obra_Classificacao` FOREIGN KEY (`idClassificacao`) REFERENCES `classificacao` (`idClassificacao`) ON UPDATE CASCADE,
  CONSTRAINT `fk_Obra_Colecao` FOREIGN KEY (`idColecao`) REFERENCES `colecao` (`idColecao`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `obra`
--

INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("1","Luminria","Luminria sertaneja tpica","","Serto da Bahia","","Uma luminria tpica do serto da bahia.","66","49","1.5","2","3","4","10","Plstico e couro","Vrias","Desconhecido","Alguns arranhes","","","","","","","../media/obras/imagens/1/luminaria-rustica-de-juta-e-resina-chacaras.jpg","../media/obras/imagens/1/lu-potes.jpg","","","","../media/obras/modelo3d/1/lamp.obj");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("2","Pote","Pote sertanejo tpica","","Feira de Santana","","Um pote tpico do serto da bahia.","1","49","1.5","2","3","4","10","Cermica","Vrias","Desconhecido","Alguns arranhes","","","","","","","../media/obras/imagens/2/pote.jpg","","","","","../media/obras/modelo3d/2/pote.obj");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("3","Rosto Asssustado","Rosto Asssustado do Serto","","Serto da Bahia","","Uma caricatura tpica do serto da bahia.","3","3","1.5","2","3","4","10","Cermica","Vrias","Desconhecido","Alguns arranhes","","","","","","","../media/obras/imagens/3/caricatura.jpg","","","","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("4","Chapu Tpico","Chapu Tpico de Sertanejo","","Serto da Bahia","","Um chapu tpico do serto da bahia.","6","6","1.5","2","3","4","10","Couro","Vrias","Desconhecido","Alguns arranhes","","","","","","","../media/obras/imagens/4/chapeu.jpg","","","","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("5","Ferro de Passar Roupa","Ferro de Passar Roupa Carvo","","Serto da Bahia","","Um ferro de passar tpico do serto da bahia.","5","49","1.5","2","3","4","10","Ferro e carvo","Vrias","Desconhecido","Alguns arranhes","","","","","","","../media/obras/imagens/5/f1.jpg","../media/obras/imagens/5/f2.jpg","","","","");
INSERT INTO obra (`numeroInventario`,`nome`,`titulo`,`funcao`,`origem`,`procedencia`,`descricao`,`idColecao`,`idClassificacao`,`altura`,`largura`,`diametro`,`peso`,`comprimento`,`materiaisContruidos`,`tecnicasFabricacao`,`autoria`,`marcasInscricoes`,`historicoObjeto`,`modoAquisicao`,`dataAquisicao`,`autor`,`observacoes`,`estadoConservacao`,`caminhoImagem1`,`caminhoImagem2`,`caminhoImagem3`,`caminhoImagem4`,`caminhoImagem5`,`caminhoModelo3D`) VALUES ("45355","sadfsdffdf","fdfdsfds","","","","","6","49","","","","","","","","","","","","","","","","../media/obras/imagens/45355/icone.png","","","","","../media/obras/modelo3d/45355/");



-- -----------------------------------------------------
-- Table `webMuseu`.`opcao`
-- -----------------------------------------------------

DROP TABLE IF EXISTS opcao;
CREATE TABLE `opcao` (
  `idOpcao` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(45) NOT NULL,
  PRIMARY KEY (`idOpcao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `opcao`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`pergunta`
-- -----------------------------------------------------

DROP TABLE IF EXISTS pergunta;
CREATE TABLE `pergunta` (
  `idPergunta` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(45) NOT NULL,
  `opcional` tinyint(1) NOT NULL,
  `tipo` enum('ABERTA','UNICA ESCOLHA','MULTIPLA ESCOLHA') NOT NULL,
  PRIMARY KEY (`idPergunta`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `pergunta`
--

INSERT INTO pergunta (`idPergunta`,`titulo`,`opcional`,`tipo`) VALUES ("1","fdsfdsdffdfds","1","ABERTA");



-- -----------------------------------------------------
-- Table `webMuseu`.`perguntaopcao`
-- -----------------------------------------------------

DROP TABLE IF EXISTS perguntaopcao;
CREATE TABLE `perguntaopcao` (
  `idPergunta` int(11) NOT NULL,
  `idOpcao` int(11) NOT NULL,
  PRIMARY KEY (`idPergunta`,`idOpcao`),
  KEY `fk_PerguntaOpcao_Opcao_idx` (`idOpcao`),
  CONSTRAINT `fk_PerguntaOpcao_Opcao` FOREIGN KEY (`idOpcao`) REFERENCES `opcao` (`idOpcao`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_PerguntaOpcao_Pergunta` FOREIGN KEY (`idPergunta`) REFERENCES `pergunta` (`idPergunta`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `perguntaopcao`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`perguntapesquisa`
-- -----------------------------------------------------

DROP TABLE IF EXISTS perguntapesquisa;
CREATE TABLE `perguntapesquisa` (
  `idPergunta` int(11) NOT NULL,
  `idPesquisa` int(11) NOT NULL,
  PRIMARY KEY (`idPergunta`,`idPesquisa`),
  KEY `fk_PerguntaPesquisa_Pesquisa_idx` (`idPesquisa`),
  CONSTRAINT `fk_PerguntaPesquisa_Pergunta` FOREIGN KEY (`idPergunta`) REFERENCES `pergunta` (`idPergunta`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_PerguntaPesquisa_Pesquisa` FOREIGN KEY (`idPesquisa`) REFERENCES `pesquisa` (`idPesquisa`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `perguntapesquisa`
--

INSERT INTO perguntapesquisa (`idPergunta`,`idPesquisa`) VALUES ("1","1");



-- -----------------------------------------------------
-- Table `webMuseu`.`pesquisa`
-- -----------------------------------------------------

DROP TABLE IF EXISTS pesquisa;
CREATE TABLE `pesquisa` (
  `idPesquisa` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(45) NOT NULL,
  `descricao` varchar(200) DEFAULT NULL,
  `estaAtiva` tinyint(1) NOT NULL,
  PRIMARY KEY (`idPesquisa`),
  UNIQUE KEY `titulo_UNIQUE` (`titulo`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `pesquisa`
--

INSERT INTO pesquisa (`idPesquisa`,`titulo`,`descricao`,`estaAtiva`) VALUES ("1","fefdsf","Sem descrio","1");



-- -----------------------------------------------------
-- Table `webMuseu`.`respostaaberta`
-- -----------------------------------------------------

DROP TABLE IF EXISTS respostaaberta;
CREATE TABLE `respostaaberta` (
  `idUsuario` int(11) NOT NULL,
  `idPesquisa` int(11) NOT NULL,
  `idPergunta` int(11) NOT NULL,
  `descricao` text NOT NULL,
  PRIMARY KEY (`idUsuario`,`idPesquisa`,`idPergunta`),
  KEY `fk_RespostaAberta_Pergunta_idx` (`idPergunta`),
  KEY `fk_RespostaAberta_Pesquisa_idx` (`idPesquisa`),
  CONSTRAINT `fk_RespostaAberta_Pergunta` FOREIGN KEY (`idPergunta`) REFERENCES `pergunta` (`idPergunta`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_RespostaAberta_Pesquisa` FOREIGN KEY (`idPesquisa`) REFERENCES `pesquisa` (`idPesquisa`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_RespostaAberta_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `respostaaberta`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`respostafechada`
-- -----------------------------------------------------

DROP TABLE IF EXISTS respostafechada;
CREATE TABLE `respostafechada` (
  `idUsuario` int(11) NOT NULL,
  `idPesquisa` int(11) NOT NULL,
  `idPergunta` int(11) NOT NULL,
  `idOpcao` int(11) NOT NULL,
  PRIMARY KEY (`idUsuario`,`idPesquisa`,`idPergunta`,`idOpcao`),
  KEY `fk_RespostaSelecionada_Opcao_idx` (`idOpcao`),
  KEY `fk_RespostaFechada_Pergunta_idx` (`idPergunta`),
  KEY `fk_RespostaFechada_Pesquisa_idx` (`idPesquisa`),
  CONSTRAINT `fk_RespostaFechada_Opcao` FOREIGN KEY (`idOpcao`) REFERENCES `opcao` (`idOpcao`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_RespostaFechada_Pergunta` FOREIGN KEY (`idPergunta`) REFERENCES `pergunta` (`idPergunta`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_RespostaFechada_Pesquisa` FOREIGN KEY (`idPesquisa`) REFERENCES `pesquisa` (`idPesquisa`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_RespostaFechada_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `respostafechada`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`tag`
-- -----------------------------------------------------

DROP TABLE IF EXISTS tag;
CREATE TABLE `tag` (
  `idTag` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(45) NOT NULL,
  PRIMARY KEY (`idTag`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `tag`
--

INSERT INTO tag (`idTag`,`descricao`) VALUES ("1","tag teste");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("2","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("3","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("4","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("5","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("6","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("7","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("8","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("9","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("10","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("11","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("12","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("13","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("14","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("15","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("16","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("17","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("18","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("19","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("20","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("21","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("22","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("23","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("24","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("25","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("26","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("27","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("28","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("29","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("30","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("31","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("32","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("33","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("34","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("35","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("36","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("37","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("38","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("39","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("40","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("41","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("42","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("43","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("44","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("45","valmir");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("46","vini");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("47","");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("48","fode");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("49","caralho");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("50","porra");
INSERT INTO tag (`idTag`,`descricao`) VALUES ("51","merda");



-- -----------------------------------------------------
-- Table `webMuseu`.`tagobra`
-- -----------------------------------------------------

DROP TABLE IF EXISTS tagobra;
CREATE TABLE `tagobra` (
  `idTag` int(11) NOT NULL,
  `idObra` int(11) NOT NULL,
  PRIMARY KEY (`idTag`,`idObra`),
  KEY `fk_idObra_idx` (`idObra`),
  CONSTRAINT `fk_TagObra_Obra` FOREIGN KEY (`idObra`) REFERENCES `obra` (`numeroInventario`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_TagObra_Tag` FOREIGN KEY (`idTag`) REFERENCES `tag` (`idTag`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `tagobra`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`usuario`
-- -----------------------------------------------------

DROP TABLE IF EXISTS usuario;
CREATE TABLE `usuario` (
  `idUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(20) NOT NULL,
  `sobrenome` varchar(45) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `senha` varchar(50) DEFAULT NULL,
  `cadastroConfirmado` tinyint(1) NOT NULL,
  `tipoUsuario` enum('USUARIO','FUNCIONARIO','ADMINISTRADOR') DEFAULT NULL,
  PRIMARY KEY (`idUsuario`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=336 DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `usuario`
--

INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("1","Jamylle","Santana","jamyllesf@gmail.com","25d55ad283aa400af464c76d713c07ad","1","ADMINISTRADOR");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("2","Usurio","Comum","usuariocomum@gmail.com","2e9ec317e197819358fbc43afca7d837","1","USUARIO");
INSERT INTO usuario (`idUsuario`,`nome`,`sobrenome`,`email`,`senha`,`cadastroConfirmado`,`tipoUsuario`) VALUES ("3","Funcionrio","Museu","funcionariomuseu@gmail.com","551b50cd77c369891fa02b5dc73c03a7","1","FUNCIONARIO");



-- -----------------------------------------------------
-- Table `webMuseu`.`usuarioacessoobra`
-- -----------------------------------------------------

DROP TABLE IF EXISTS usuarioacessoobra;
CREATE TABLE `usuarioacessoobra` (
  `numeroInventario` int(11) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  PRIMARY KEY (`idUsuario`,`numeroInventario`),
  KEY `fk_UsuarioAcesso_Usuario_idx` (`idUsuario`),
  KEY `fk_UsuarioAcesso_AcessoObra_idx` (`numeroInventario`),
  CONSTRAINT `fk_UsuarioAcesso_AcessoObra` FOREIGN KEY (`numeroInventario`) REFERENCES `obra` (`numeroInventario`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_UsuarioAcesso_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `usuarioacessoobra`
--

INSERT INTO usuarioacessoobra (`numeroInventario`,`idUsuario`) VALUES ("1","3");
INSERT INTO usuarioacessoobra (`numeroInventario`,`idUsuario`) VALUES ("2","3");
INSERT INTO usuarioacessoobra (`numeroInventario`,`idUsuario`) VALUES ("5","3");



-- -----------------------------------------------------
-- Table `webMuseu`.`usuariofacebook`
-- -----------------------------------------------------

DROP TABLE IF EXISTS usuariofacebook;
CREATE TABLE `usuariofacebook` (
  `idUsuarioFacebook` varchar(50) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  PRIMARY KEY (`idUsuarioFacebook`),
  KEY `fk_UsuarioFacebook_Usuario_idx` (`idUsuario`),
  CONSTRAINT `fk_UsuarioFacebook_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `usuariofacebook`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`usuariogoogle`
-- -----------------------------------------------------

DROP TABLE IF EXISTS usuariogoogle;
CREATE TABLE `usuariogoogle` (
  `idUsuarioGoogle` varchar(50) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  PRIMARY KEY (`idUsuarioGoogle`),
  KEY `fk_UsuarioGoogle_Usuario_idx` (`idUsuario`),
  CONSTRAINT `fk_UsuarioGoogle_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `usuariogoogle`
--




-- -----------------------------------------------------
-- Table `webMuseu`.`usuariorespostapesquisa`
-- -----------------------------------------------------

DROP TABLE IF EXISTS usuariorespostapesquisa;
CREATE TABLE `usuariorespostapesquisa` (
  `idUsuario` int(11) NOT NULL,
  `idPesquisa` int(11) NOT NULL,
  PRIMARY KEY (`idUsuario`,`idPesquisa`),
  KEY `fk_UsuarioRespostaPesquisa_Pesquisa_idx` (`idPesquisa`),
  CONSTRAINT `fk_UsuarioRespostaPesquisa_Pesquisa` FOREIGN KEY (`idPesquisa`) REFERENCES `pesquisa` (`idPesquisa`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_UsuarioRespostaPesquisa_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------
-- Dump Data for `usuariorespostapesquisa`
--




